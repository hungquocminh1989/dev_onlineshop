<?php
/**
 * 汎用関数
 * @category   ACWork
 * @copyright  2016
 * @version    0.1
 */
class ACWFunc
{
	/**
	 * SSL判定
	 * @return	boolean	true:sslによる通信である
	 */
	public static function is_ssl()
	{
		if (! empty($_SERVER['HTTPS'])) {
			if (strtolower($_SERVER['HTTPS']) !== 'off') {
				return true;
			}
		}
		if (isset($_SERVER['SERVER_PORT'])) {
			if ((int)$_SERVER['SERVER_PORT'] === 443) {
				return true;
			}
		}
		if (isset($_SERVER['HTTP_X_FORWARDED_PROTOCOL'])) {
			if (strtolower($_SERVER['HTTP_X_FORWARDED_PROTOCOL']) === 'https') {
				return true;
			}
		}
		return false;
	}

	/**
	 * AJAX判定
	 * @return	boolean	true:ajaxによる通信である
	 */
	public static function is_ajax()
	{
		return (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest');
	}

	/**
	 * POST判定
	 * @return	boolean	true:POSTリクエストである
	 */
	public static function is_post()
	{
		return (isset($_SERVER['REQUEST_METHOD']) && strtolower($_SERVER['REQUEST_METHOD']) === 'post');
	}

	/**
	 * IE判定
	 * @param	boolean	true:EdgeもIEに含める
	 * @return	boolean	true:IEである
	 */
	public static function is_ie($and_edge = true)
	{
		$ua = isset($_SERVER['HTTP_USER_AGENT']) ? strtolower($_SERVER['HTTP_USER_AGENT']) : '';
		if ((strpos($ua, 'trident') !== false) || (strpos($ua, 'msie') !== false)) {
			return true;
		}
		return $and_edge ? (strpos($ua, 'edge') !== false) : false;
	}

	/**
	 * スラッシュ除去
	 * @param	string	除去前文字列
	 * @return	string	除去後文字列
	 */
	public static function remove_slash($str)
	{
		return str_replace('/', '', $str);
	}

	/**
	 * カンマ除去
	 * @param	string	除去前文字列
	 * @return	string	除去後文字列
	 */
	public static function remove_comma($str)
	{
		return str_replace(',', '', $str);
	}

	/**
	 * 改行除去
	 * @param	string	除去前文字列
	 * @return	string	除去後文字列
	 */
	public static function remove_crlf($str)
	{
		return str_replace(array("\r\n","\n","\r"), '', $str);
	}

	/**
	 * 右トリム「空白」
	 * @param	string	処理前文字列
	 * @return	string	処理後文字列
	 */
	public static function rtrim_space($str)
	{
		return preg_replace('/[　]+$/u', '', rtrim($str));
	}

	/**
	 * 全角変換
	 * @param	string	変換前文字列
	 * @return	string	変換後文字列
	 */
	public static function convert_zenkaku($str)
	{
		$str = mb_convert_kana($str, 'ASKV');
		return str_replace(array('"', '\'', '~', '\\'), array('”', '’', '～', '￥'), $str);
	}

	/**
	 * 半角変換
	 * @param	string	変換前文字列
	 * @return	string	変換後文字列
	 */
	public static function convert_hankaku($str)
	{
		$str = mb_convert_kana($str, 'askh');
		return str_replace(array('”', '’', '～', '￥'), array('"', '\'', '~', '\\'), $str);
	}
}
