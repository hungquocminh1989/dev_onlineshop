<?php
/**
 * ログを取るクラス
 *
 * @category   ACWork
 * @copyright  2014
 * @version	0.92
*/
class ACWLog
{
	/**
	 * ログインユーザーごとにログを分ける
	 */
	private static $_user_file_suffix = "";

	/**
	 * ログディレクトリ
	 */
	private static $_log_dir = null;

	/**
	 * 書込可能
	 */
	private static $_writable = true;

	public static function able()
	{
		self::$_writable = true;
	}
	public static function disable()
	{
		self::$_writable = false;
	}

	/**
	 * エラーログを取る
	 * @param string $suffix ファイル名の末尾
	 * @param string $msg メッセージ
	 */
	public static function err($file_suffix, $e)
	{
		if (self::$_writable === false) {
			return;
		}

		$msg = $e->getMessage();
		$msg .= "\n" . var_export(ACWCore::$my, true);
		$msg .= "\n" . $e->getTraceAsString();
		static::write_file($file_suffix, $msg);
		
		if (ERROR_SEND_MAIL === true) {
			/**
			 * メール送信
			 */
			$errmailer = new ErrorMailer_lib();
			$errmailer->send($msg);
		}
	}

	/**
	 * エラーログを取る
	 * @param string $suffix ファイル名の末尾
	 * @param string $msg メッセージ
	 */
	public static function debug($msg)
	{
		$msg = print_r($msg, true);
		static::write_file("Debug", $msg);
	}

	/**
	 * SQLエラーログを取る
	 * @param string $suffix ファイル名の末尾
	 * @param string $msg メッセージ
	 */
	public static function sql_err($msg)
	{
		static::write_file('SQLERROR', $msg);
	}

	/**
	 * SQL文だけのログを取る
	 * @param string $filename ファイル名
	 * @param string $msg メッセージ
	 */
	public static function sql_statement($sql)
	{
		static::write_file('SQLLOG', $sql);
	}

	/**
	 * SQLパラメタけのログを取る
	 * @param string $filename ファイル名
	 * @param string $msg メッセージ
	 */
	public static function sql_param($param)
	{
		static::write_file('SQLLOG', var_export($param, true));
	}

	/**
	* SQL文とパラメタの両方のログを取る
	* @param string $filename ファイル名
	* @param string $msg メッセージ
	*/
	public static function sql($sql, $param)
	{
		if (self::$_writable === false) {
			return;
		}

		$line = $sql . "\r\n";
		if (is_null($param) == false) {
			$line .= var_export($param, true);
		}
		static::write_file('SQLLOG', $line);
	}

	/**
	 * ログファイル出力
	 * @param string $suffix ファイル名の末尾
	 * @param string $str メッセージ
	 */
	public static function write_file($suffix, $str)
	{
		if (self::$_writable === false) {
			return;
		}

		$filepath = static::make_filepath($suffix);
		if (($fp = @fopen($filepath, "a")) === false) {
			return;
		}

		fwrite($fp, static::make_header() . $str . "\n");

		fclose($fp);

		if (ACW_WINDOWS == false) {
			chmod($filepath, 0755);
		}
	}
	
	/**
	 * ユーザー用ファイル末尾設定
	 * ログインユーザー毎にログファイルを分ける
	 * @param string $suffix ファイル名の末尾
	 */
	public static function set_user_suffix($suffix)
	{
		static::$_user_file_suffix = $suffix;
	}

	/**
	 * ログディレクトリを標準の場所から変更する
	 * @param string $log_dir ログディレクトリ
	 */
	public static function change_log_dir($log_dir)
	{
		static::$_log_dir = $log_dir;
	}

	/**
	 * ログディレクトリを標準の場所に戻す
	 */
	public static function reset_log_dir()
	{
		static::$_log_dir = null;
	}

	/**
	 * ファイル名作成
	 * @param string $suffix ファイル名の末尾
	 */
	protected static function make_filepath($suffix)
	{
		if (static::$_user_file_suffix != '') {
			$suffix .= '_' . static::$_user_file_suffix;
		}

		$log_dir = (isset(static::$_log_dir)) ? static::$_log_dir : ACW_LOG_DIR;

		return $log_dir . '/' . date('Ymd') . '_' . $suffix . '.log';
	}

	/**
	 * ファイルのヘッダ部分を作成
	 */
	protected static function make_header()
	{
		if (isset($_SERVER["REMOTE_ADDR"])) {
			return date('Y/m/d H:i:s') . ' access ip -> ' . $_SERVER["REMOTE_ADDR"] . "\n";
		}

		return date('Y/m/d H:i:s') . "\n";
	}

	/**
	 *
	 * デバッグ用
	 *
	 */
	public static function debug_var($predix, $var)
	{
		static::write_file($predix, var_export($var, true));
	}

//Add Start IKO_VN-1 hungtn VNIT 20170725
	public static function write_file_action($str)
	{
		if (self::$_writable === false) {
			return;
		}

		$log_dir = (isset(static::$_log_dir)) ? static::$_log_dir : ACW_LOG_DIR;
		$filepath =  $log_dir . '/mecha_admin_' . date('Ym') . '.log';

		if (($fp = @fopen($filepath, "a")) === false) {
			return;
		}

		$header = date('Y/m/d H:i:s') ." : ";
		if (isset($_SERVER["REMOTE_ADDR"])) {
			$header = date('Y/m/d H:i:s') . ' access ip -> ' . $_SERVER["REMOTE_ADDR"] ." : ";
		}

		fwrite($fp, $header . $str . "\n");

		fclose($fp);

		if (ACW_WINDOWS == false) {
			chmod($filepath, 0755);
		}
	}

	public static function debug_var_action($model_name, $action_method, $message = '')
	{
		if(Dfn::LOG_USER_ACTION_FLG == false) return false;

		$user_info = ACWSession::get('user_info');
		if(isset($user_info['USER_NM'])) {
			//$_REQUEST
			$screen_define = Dfn::SCREEN_DEFINE;
			$user_info_nm = $user_info['USER_NM'];

			$model_name = strtolower($model_name);
			$action_method =  strtolower($action_method);
			if(isset($screen_define[$model_name][$action_method])) {

				$param_implode = json_encode($_REQUEST);
				
				$screen_enter = $screen_define[$model_name][$action_method];
				if($message != '' ) {
					static::write_file_action( $screen_enter . ' '.$user_info_nm.' : '.$message);
				} else {
					static::write_file_action( $screen_enter . ' '.$user_info_nm.'  Param: '.$param_implode);
				}
			}
		}
	}
//Add End IKO_VN-1 hungtn VNIT 20170725
}

/**
 * ACWLog::debug のエイリアス
 * @param 出力内容 $obj
 */
function var_log($obj)
{
	ACWLog::debug($obj);
}
/* ファイルの終わり */