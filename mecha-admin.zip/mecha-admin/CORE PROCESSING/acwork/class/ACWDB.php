<?php
/**
 * データベースコネクション基本クラス
 *
 * 基本クラスであり、継承して使います
 *
 * @category   ACWork
 * @copyright  2014
 * @version    0.953
*/
class ACWDB
{
	/**
	 * DBコネクション
	 */
	private $_dbh;

	/**
	 * トランザクションが開始されたかどうか
	 */
	private $_started;

	/**
	 * コード変換情報
	 */
	private $_enc;

	private $_last_param;
	private $_last_sql;
	private $_logname_def;
	private $_logname_err;
	private $_log_writable;

	/**
	 * コンストラクタ
	 * @param string $target 接続先 パラメタが空の場合は既定の接続先へ
	 */
	public function __construct($target = '', $log_writable = true)
	{
		$suffix = strlen($target) ? '_' . $target : '';
		$this->_logname_def  = 'SQLLOG'   . $suffix;
		$this->_logname_err  = 'SQLERROR' . $suffix;
		$this->_log_writable = $log_writable;

		if (isset(ACWCore::$db_conn[$target])) {
			// 既に接続済み
			$conn = ACWCore::$db_conn[$target];
			$this->_dbh = $conn['dbh'];
			$this->_enc = $conn['enc'];

		} else {
			// 接続パラメタ（config系ファイルに設定済のもの）
			$dpparm = acwork_db($target);
			$this->_dbh = null;
			$this->_enc = null;

			try {
				$this->_dbh = new PDO($dpparm['dsn'], $dpparm['username'], $dpparm['password'], $dpparm['driver_options']);
				$this->_dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			} catch (PDOException $e) {
				$this->_db_error($e);
			}

			// コード変換するか
			if (isset($dpparm['convert_encoding'])) {
				$in_enc = mb_internal_encoding();
				$db_enc = $dpparm['convert_encoding'];
				if ($in_enc != $db_enc) {
					$this->_enc = array(
						'php' => $in_enc,
						'db' => $db_enc,
					);
				}
			}
			ACWCore::$db_conn[$target] = array(
				'dbh' => $this->_dbh,
				'enc' => $this->_enc,
			);
		}
		$this->_started = false;
	}

	/**
	 * トランザクション開始
	 */
	protected function begin_transaction()
	{
		try {
			$this->_dbh->beginTransaction();
		} catch (PDOException $e) {
			$this->_db_error($e);
		}
		$this->_started = true;
	}

	/**
	 * トランザクションコミット
	 */
	protected function commit()
	{
		try {
			$this->_dbh->commit();
		} catch (PDOException $e) {
			$this->_db_error($e);
		}
		$this->_started = false;
	}

	/**
	 * トランザクションロールバック
	 */
	protected function rollback()
	{
		if ($this->_started == false) {
			return;	// 2回やらない
		}
		$this->_started = false;
		try {
			$this->_dbh->rollBack();
		} catch (PDOException $e) {
			$this->_db_error($e);
		}
	}

	/**
	 * 参照系実行
	 */
	protected function query($sql, $param = null)
	{
		// ログ
		$this->_writelog($sql, $param);
		// PREPARE
		$stmt = $this->_internal_prepare($sql);
		// 実行
		$this->_internal_execute($stmt, $param);
		// FETCH
		return $this->_internal_fetch($stmt);
	}

	/**
	 * 更新系実行
	 */
	protected function execute($sql, $param = null)
	{
		// トランザクションチェック
		$this->_check_transaction();
		// ログ
		$this->_writelog($sql, $param);
		// PREPARE
		$stmt = $this->_internal_prepare($sql);
		// 実行
		$this->_internal_execute($stmt, $param);
	}

	/**
	 * パラメタ出力があるプロシージャ実行
	 * @param string $out_param 入出力用パラメタ 省略不可
	 * @param string $in_param 入力専用パラメタ
	 * @param string $out_length 出力用パラメタの長さ
	 */
	protected function execute_procedure($sql, &$out_param, $in_param = null, $out_length = 8000)
	{
		// ログ
		$this->_writelog($sql, $in_param);

		// PREPARE
		$stmt = $this->_internal_prepare($sql);
		try {
			if (is_null($in_param) == false) {
				if (isset($this->_enc)) {
					// DBのコードへ変換
					$in_param = $this->_enc2db($in_param);
				}

				// パラメタ設定
				foreach ($in_param as $key => $val) {
					if ($this->_is_db_null($val) == true) {
						// NULLの場合
						$stmt->bindValue(':' . $key, null, PDO::PARAM_NULL);
					} else {
						if ($key == 'iv_SES') {
							$ses = $val;
							$stmt->bindParam(':' . $key, $ses, PDO::PARAM_STR, strlen($ses));
						}
						elseif ($key == 'iv_REQ') {
							$req = $val;
							$stmt->bindParam(':' . $key, $req, PDO::PARAM_STR, strlen($req));
						}
						else {
							$stmt->bindValue(':' . $key, $val);
						}
					}
				}
			}
			if (is_null($out_param) == false) {
				if (isset($this->_enc)) {
					// DBのコードへ変換
					$out_param = $this->_enc2db($out_param);
				}
			}
			// パラメタ設定
			foreach ($out_param as $key => $val) {
				if ($this->_is_db_null($val) == true) {
					$out_param[$key] = null;
				}
				$stmt->bindParam(':' . $key, $out_param[$key], PDO::PARAM_STR|PDO::PARAM_INPUT_OUTPUT, $out_length);
			}

			$stmt->execute(); // プロシージャ実行

			if (isset($this->_enc)) {
				// DBのコードへ変換
				$out_param = $this->_enc2php($out_param);
			}
			// ログ
			$this->_writelog('procedure_response', $out_param);

		} catch (PDOException $e) {
			$this->_db_error($e);
		}
	}

	/**
	 * Webサービス参照系実行
	 */
	protected function web_query($sql, $param = null)
	{
		// ログ
		$this->_writelog($sql, $param);
		
		// パラメータ設定
		$req = BROKER_URL . 'BROKER_GUID=' . urlencode(BROKER_GUID) . '&REQ_TYPE=' . 'QUERY' . '&SQL=' . urlencode($sql);
		if ($param !== null) {
			foreach ($param as $key => $value) {
				$req .= '&' . $key . '=' . urlencode($value);
			}
		}
		
		// 実行
		$res = file_get_contents($req);

		// 結果設定
		$result = json_decode($res, true);
		if ($result['BROKER_RESULT'] === 'S') {
			$e = new ErrorException($result['EXCEPTION_MSG']);
			throw $e;
		}
		return $result['DS'];
	}

	/**
	 * Webサービス更新系実行
	 */
	protected function web_execute($sql, $param = null)
	{
		// ログ
		$this->_writelog($sql, $param);
		
		// パラメータ設定
		$req = BROKER_URL . 'BROKER_GUID=' . urlencode(BROKER_GUID) . '&REQ_TYPE=' . 'NONQUERY' . '&SQL=' . urlencode($sql);
		if ($param !== null) {
			foreach ($param as $key => $value) {
				$req .= '&' . $key . '=' . urlencode($value);
			}
		}
		
		// 実行
		$res = file_get_contents($req);

		// 結果設定
		$result = json_decode($res, true);
		if ($result['BROKER_RESULT'] === 'S') {
			$e = new ErrorException($result['EXCEPTION_MSG']);
			throw $e;
		}
	}

	/**
	 * Webサービスパラメタ出力があるプロシージャ実行
	 * @param string $out_param 入出力用パラメタ 省略不可
	 * @param string $in_param 入力専用パラメタ
	 * @param string $out_length 出力用パラメタの長さ
	 */
	protected function web_execute_procedure($sql, &$out_param, $in_param = null, $out_length = 8000)
	{
		// ログ
		$this->_writelog($sql, $in_param);

		// パラメータ設定
		$req = BROKER_URL . 'BROKER_GUID=' . urlencode(BROKER_GUID) . '&REQ_TYPE=' . 'NONQUERY' . '&SQL=' . urlencode($sql);
		if ($in_param !== null) {
			foreach ($in_param as $key => $value) {
				$req .= '&' . $key . '=' . urlencode($value);
			}
		}
		if ($out_param !== null) {
			foreach ($out_param as $key => $value) {
				$req .= '&' . $key . '=' . 'null';
			}
		}
		
		// 実行
		$res = file_get_contents($req);

		// 結果設定
		$result = json_decode($res, true);
		if ($result['BROKER_RESULT'] === 'S') {
			$e = new ErrorException($result['EXCEPTION_MSG']);
			throw $e;
		}

		// 出力パラメータ設定
		if ($out_param !== null) {
			foreach ($out_param as $key => $value) {
				$out_param[$key] = $result[$key];
			}
		}

		// ログ
		$this->_writelog('procedure_response', $out_param);
	}

	/**
	 * SQLを登録しておく
	 */
	protected function prepare($sql)
	{
		// ログ
		$this->_writelog($sql);
		return $this->_internal_prepare($sql);
	}

	/**
	 * 既に定義したSQLを実行する（更新系）
	 */
	protected function prepared_execute($stmt, $param = null)
	{
		// トランザクションチェック
		$this->_check_transaction();
		// ログ
		$this->_writelog('prepared_execute', $param);
		// 実行
		$this->_internal_execute($stmt, $param);
	}

	/**
	 * 既に定義したSQLを問い合わせする（参照系）
	 */
	protected function prepared_query($stmt, $param = null)
	{
		// ログ
		$this->_writelog('prepared_query', $param);
		// 実行
		$this->_internal_execute($stmt, $param);
		// FETCH
		return $this->_internal_fetch($stmt);
	}

	/**
	 * 更新時にトランザクションが開始されているかどうか
	 */
	private function _check_transaction()
	{
		if ($this->_started == false) {
			throw new Exception('内部エラー トランザクションが開始されていません。');
		}
	}

	/**
	 * SQLを登録（内部関数）
	 */
	private function _internal_prepare($sql)
	{
		$this->_last_sql   = null;
		$this->_last_param = null;
		try {
			if (isset($this->_enc)) {
				// DBのコードへ変換
				$sql = $this->_enc2db($sql);
			}
			$this->_last_sql = $sql;
			$stmt = $this->_dbh->prepare($sql);

		} catch (PDOException $e) {
			$this->_db_error($e);
		}
		return $stmt;
	}

	/**
	 * SQL実行（内部関数）
	 */
	private function _internal_execute($stmt, $param)
	{
		try {
			if (is_null($param) == false) {
				if (isset($this->_enc)) {
					// DBのコードへ変換
					$param = $this->_enc2db($param);
				}
				$this->_last_param = $param;

				// パラメタ設定
				foreach ($param as $key => $val) {
					if ($this->_is_db_null($val) == true) {
						// NULLの場合
						$stmt->bindValue(':' . $key, null, PDO::PARAM_NULL);
					} else {
						$stmt->bindValue(':' . $key, $val);
					}
				}
			}
			$stmt->execute(); // クエリ実行
		} catch (PDOException $e) {
			$this->_db_error($e);
		}
	}

	/**
	 * データ取得（内部関数）
	 */
	private function _internal_fetch($stmt)
	{
		$all = array();
		try {
			// 配列で返す
			for (;;) {
				$result = $stmt->fetch(PDO::FETCH_ASSOC);
				if ($result === false) {
					break;
				}
				if (isset($this->_enc)) {
					// DBのコードから変換
					$all[] = $this->_enc2php($result);
				} else {
					$all[] = $result;
				}
			}
		} catch (PDOException $e) {
			$this->_db_error($e);
		}

		return $all;
	}

	/**
	 * NULL判定
	 */
	private function _is_db_null($value)
	{
		if (is_null($value)) {
			return true;
		}
		if (is_string($value) == false) {
			settype($value, 'string');
		}
		if ($value == '') {
			return true;
		}
		return false;
	}

	/**
	 * DBエラー
	 */
	private function _db_error($e)
	{
		if ($this->_started == true) {
			$this->_started = false;
			$this->_dbh->rollBack();
		}

		if (isset($this->_enc)) {
			// DBのコードからエラーメッセージを変換
			$err_msg = $this->_enc2php($e->getMessage());
		} else {
			$err_msg = $e->getMessage();
		}

		// エラーを追加する
		ACWError::add('db_error', $err_msg);
		// エラーログを吐く
		$line = $e->getMessage();	// ファイルはDB文字コード
		$line .= $this->_last_sql . "\r\n";
		if (is_null($this->_last_param) == false) {
			$line .= var_export($this->_last_param, true) . "\r\n";
		}
		ACWLog::write_file($this->_logname_err, $line);

		if (isset($this->_enc)) {
			// エラーメッセージを変換
			$e = new ErrorException($err_msg);
		}

		throw $e;
	}

	/**
	 * 文字コード変換
	 */
	private function _enc_convert($param, $fr, $to)
	{
		if (is_string($param)) {
			return mb_convert_encoding($param, $to, $fr);
		}
		if (is_array($param)) {
			$ary = array();
			foreach ($param as $k => $v) {
				$ary[mb_convert_encoding($k, $to, $fr)] = is_null($v) ? null : mb_convert_encoding($v, $to, $fr);
			}
			return $ary;
		}
		return param;
	}

	/**
	 * 文字コード変換：PHP→DB
	 */
	private function _enc2db($param)
	{
		return $this->_enc_convert($param, $this->_enc['php'], $this->_enc['db']);
	}

	/**
	 * 文字コード変換：DB→PHP
	 */
	private function _enc2php($param)
	{
		return $this->_enc_convert($param, $this->_enc['db'], $this->_enc['php']);
	}

	/**
	 * SQLログを取る
	 */
	private function _writelog($sql, $param = null)
	{
		if (! $this->_log_writable) {
			return; // ログを出力しない
		}
		if (! empty($param)) {
			$sql .= "\r\n" . var_export($param, true);
		}
		ACWLog::write_file($this->_logname_def, $sql);
	}
}
/* ファイルの終わり */