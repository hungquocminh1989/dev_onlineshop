<?php
/**
 * セッションを操作するクラス $_SESSIONを直接操作してはいけません。
 * ログを取ったりするので
 * 
 *
 * @category   ACWork
 * @copyright  2016
 * @version    0.97
*/
class ACWSession
{
	/**
	 * 前回のトークンの値
	 */
	static protected $pre_token;
	static protected $is_closed;

	/**
	 * 初期化
	 */
	public static function init($sid = null)
	{
		if (! isset($_SESSION)) {
			// タイムアウト設定
			if (defined('ACW_TIMEOUT') && (0 < ACW_TIMEOUT)) {
				ini_set('session.gc_maxlifetime', ACW_TIMEOUT);
				session_set_cookie_params(ACW_TIMEOUT);
			}
			// セッション保存パス設定
			if (defined('ACW_SESSION_DIR')) {
				ini_set('session.save_path', ACW_SESSION_DIR);
			}
			session_name(str_replace('.', '_', ACW_PROJECT)); // dot不可（PHP仕様）
			if ($sid) {
				session_id($id);
			}
			session_start();
			self::$is_closed = false;
		}
	}

	/**
	 * トークン処理
	 */
	public static function init_token()
	{
		$token = md5(uniqid(rand(), 1));
		self::$pre_token = self::get('acw_token');
		self::set('acw_token', $token);
	}

	/**
	 * リスタート
	 */
	public static function restart()
	{
		if (self::$is_closed) {
			session_start();
			self::$is_closed = false;
		}
	}

	/**
	 * セッションのロックを解放
	 */
	public static function write_close($restart = false)
	{
		session_write_close();
		self::$is_closed = true;
		if ($restart === true) {
			self::restart();
		}
	}

	/**
	 * トークンチェック
	 */
	public static function check_token($param_token)
	{
		return ($param_token === self::get('acw_token')) ? true : false;
	}

	/**
	 * セッションID再作成
	 */
	public static function regenerate()
	{
		session_regenerate_id(true);
	}

	/**
	 * セッションID獲得
	 */
	public static function get_id()
	{
		return session_id();
	}

	/**
	 * セッションID設定（session_startより前に設定）
	 */
	public static function set_id($id)
	{
		return session_id($id);
	}

	/**
	 * 設定
	 */
	public static function set($key, $val)
	{
		if (self::$is_closed) {
			session_start();
		}

		if (is_array($key)) {
			self::_set_multi($key, $val);
		} else {
			$_SESSION[$key] = $val;
		}

		if (self::$is_closed) {
			session_write_close();
		}
	}

	/**
	 * 設定(多次元)
	 */
	private static function _set_multi($keys, $val)
	{
		$sess =& $_SESSION;
		foreach($keys as $key){
			$sess =& $sess[$key];
		}
		$sess = $val;
	}

	/**
	 * 獲得
	 */
	public static function get($key, $default = null)
	{
		if (is_array($key)) {
			return self::_get_multi($key, $default);
		}
		if (isset($_SESSION[$key])) {
			return $_SESSION[$key];
		}
		return $default;
	}

	/**
	 * 獲得(多次元)
	 */
	private static function _get_multi($keys, $default = null)
	{
		$sess = $_SESSION;
		foreach ($keys as $key) {
			if (isset($sess[$key])) {
				$sess = $sess[$key];
			} else {
				return $default;
			}
		}
		return $sess;
	}

	/**
	 * 削除
	 */
	public static function del($key)
	{
		if (self::$is_closed) {
			session_start();
		}

		if (is_array($key)) {
			return self::_del_multi($key);
		} else {
			unset($_SESSION[$key]);
		}

		if (self::$is_closed) {
			session_write_close();
		}
	}

	/**
	 * 削除(多次元)
	 */
	private static function _del_multi($keys)
	{
		$last = array_pop($keys);
		$sess =& $_SESSION;
		foreach($keys as $key){
			if (isset($sess[$key])) {
				$sess =& $sess[$key];
			} else {
				return;
			}
		}
		unset($sess[$last]);
	}

	/**
	 * セッション破棄
	 */
	public static function destroy()
	{
		$_SESSION = array();
		if (ini_get('session.use_cookies')) {
			$p = session_get_cookie_params();
			setcookie(
				session_name(), '', time() - 42000
			,	$p['path'], $p['domain'], $p['secure'], $p['httponly']
			);
		}
		session_destroy();
	}
}
/* ファイルの終わり */