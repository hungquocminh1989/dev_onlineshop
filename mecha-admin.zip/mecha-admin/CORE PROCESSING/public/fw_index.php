<?php
/**
 * 基本ファイル
 *
 * フレームワーク開始処理です。必要な部分を最初に変更します
 *
 * @category   ACWork
 * @copyright  2014 
 * @version    0.95
 */

// 内部文字エンコーディング
mb_internal_encoding('UTF-8'); // 必要に応じて

// 公開ディレクトリ
define('ACW_PUBLIC_DIR', str_replace("\\", '/', __DIR__));

// ルートディレクトリ
define('ACW_ROOT_DIR', str_replace("\\", '/', dirname(__DIR__)));

// プロジェクト名
define('ACW_PROJECT', basename(ACW_ROOT_DIR));

// タイムアウト設定（秒）
define('ACW_TIMEOUT', 60 * 60 * 1); // 必要に応じて

/**
 * デフォルトディレクトリ定義
 */
define('ACW_SYSTEM_DIR', ACW_ROOT_DIR . '/acwork');
define('ACW_APP_DIR', ACW_ROOT_DIR . '/app');
define('ACW_USER_CONFIG_DIR', ACW_ROOT_DIR . '/user_config');
define('ACW_SESSION_DIR', ACW_ROOT_DIR . '/sessions');
define('ACW_TMP_DIR', ACW_ROOT_DIR . '/tmp');
define('ACW_SMARTY_PLUGIN_DIR', ACW_APP_DIR . '/ext/smarty');
define('ACW_TEMPLATE_DIR', ACW_APP_DIR . '/template');
define('ACW_VENDOR_DIR', ACW_APP_DIR . '/vendor');
define('ACW_DATA_DIR', ACW_ROOT_DIR . '/data');

/**
 * 一時ディレクトリ
 */
define('ACW_TEMPLATE_CACHE_DIR', ACW_TMP_DIR . '/template_cache');
define('ACW_LOG_DIR', ACW_TMP_DIR . '/log');

// プロジェクトの初期化処理
require ACW_USER_CONFIG_DIR . '/initialize.php';

if (defined('STDIN') && isset($_SERVER['argv'][1])) {
	// コマンドライン実行
	ACWCore::acwork($_SERVER['argv'][1]);
} else {
	// WEB実行
	ACWCore::acwork();
}
/* ファイルの終わり */