
function showerror(message) {
	$('#message_error p').text(message);
	$('#message_error').attr('style', 'display:block;');
}

$(document).ready(function(){

    $(".dropdown-toggle").dropdown();

	 $("form input").keypress(function(e) {
	    if(e.which == 13) {
	        $("#loginbtn").trigger('click');
	    }
	});

    $("#loginbtn").click(function(){
    	data = $("form").serializeArray();

    	var result = {};

    	$.each(data, function( index, value ) {
  			result[this.name] = this.value;
		});
		
		if(result.username.trim() == '' || result.password.trim() == '') {
			showerror('ユーザーIDまたはパスワードが入力されていません。');
			return false;
		}

    	$.post( base_url+"login/checklogin",data, function(result) {
    		if(result.status != 1) {
    			showerror('ユーザーIDまたはパスワードが正しくありません。');
    			return false;
    		} else {
    			window.location.href = result.redirect;
    		}
		});

    });
});