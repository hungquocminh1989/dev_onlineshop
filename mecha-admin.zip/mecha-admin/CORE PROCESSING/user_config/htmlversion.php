<?php
/**
 * HTMLバージョン
 * cssやjs等、外部読込ファイルを更新した場合、カウントアップする
 */
define('HTMLVERSION', 11);
