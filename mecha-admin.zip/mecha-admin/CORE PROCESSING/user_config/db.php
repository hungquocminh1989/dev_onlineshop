<?php
/**
 * DB設定定義関数
 *
 * DB設定を獲得する関数です。複数DBの同時接続を可能にするためです
 *
 * @category   ACWork
 * @copyright  2013 
 * @version    0.9
 */
function acwork_db($target)
{
	$param = array();

	/**
	 * 規定値は''です
	 */
	$param[''] = array(
		'dsn' => DB_DSN,
		'username' => DB_USERNAME,
		'password' => DB_PASSWORD,
		'driver_options' => array(PDO::ATTR_PERSISTENT => false),
		//'convert_encoding' => 'SJIS-win', // データ文字コード変換
	);

	return $param[$target];
}
/* 終わり */
