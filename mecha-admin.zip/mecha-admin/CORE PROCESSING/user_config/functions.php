<?php
/**
 * プロジェクト用関数クラス
 */
class Fnc extends ACWFunc
{
	// 言語コード変換
	public static function conv_lang_cd_tag($lang_cd)
	{
		if ($lang_cd == Dfn::LANG_CD_JPN) {
			return Dfn::LANG_CD_TAG_JPN;
		}
		if ($lang_cd == Dfn::LANG_CD_ENG) {
			return Dfn::LANG_CD_TAG_ENG;
		}
		if ($lang_cd == Dfn::LANG_CD_CHN) {
			return Dfn::LANG_CD_TAG_CHN;
		}
		if ($lang_cd == Dfn::LANG_CD_KOR) {
			return Dfn::LANG_CD_TAG_KOR;
		}
	}

	/**
	 * NO SYMBOL → '　'
	 */
	public static function conv_no_symbol2big_space($value)
	{
		if ($value == Dfn::YB_KEY_NO_SYMBOL) {
			return Dfn::YB_VAL_NO_SYMBOL;
		}
		return $value;
	}

	/**
	 * NO SYMBOL変換＋説明文追加
	 */
	public static function conv_select_str($value, $no_str, $conv_str = null)
	{
		$rtn_str = '';
		if ($value == Dfn::YB_KEY_NO_SYMBOL) {
			$rtn_str = $no_str;
		} else {
			$rtn_str = $value;
		}
		if (is_null($conv_str) == false) {
			$rtn_str = $rtn_str . ':' . $conv_str;
		}
		return $rtn_str;
	}

	/**
	 * 形式表示（1…2）
	 */
	public static function conv_katashiki_str($katashiki1, $katashiki2)
	{
		if (is_null($katashiki2) == true) {
			return $katashiki1;
		}
		if ($katashiki2 == ' ') {
			return $katashiki1;
		}
		if ($katashiki2 == Dfn::YB_KEY_NO_SYMBOL) {
			return $katashiki1;
		}
		return $katashiki1 . '…' . $katashiki2;
	}

	/**
	 * 形式検索
	 * ストローク のラベルの名称を変更する形式であるか調べる
	 */
	public static function conv_label_stroke($katashiki1, $undo_hoko)
	{
		if ($katashiki1 == 'LT'
		 || $katashiki1 == 'NT'
		) {
			return 'T0217';
		}
		if ($katashiki1 == 'AT') {
			return 'T0208';
		}
		if ($katashiki1 == 'SA') {
			if ($undo_hoko == 'S0007') {
				return 'T0217';
			} else {
				return 'T0079';
			}
		}
		return 'T0026';
	}

	/**
	 * 形式検索
	 * 搭載質量 のラベルの名称を変更する形式であるか調べる
	 */
	public static function conv_label_shitsuryo($katashiki1)
	{
		if ($katashiki1 == 'LT'
		 || $katashiki1 == 'NT'
		 || $katashiki1 == 'SA'
		) {
			return 'T0209';
		}
		return 'T0028';
	}

	/**
	 * 形式検索
	 * 製品仕様の区分の項目IDを返す
	 */
	public static function get_item_id_seihin_shiyo()
	{
		return 'T0248';
	}

	/**
	 * 寿命計算
	 * 寿命計算マスタの絞り込み仕様として「ストローク長さ」を使う形式であるか調べる
	 */
	public static function check_calc_head_sr_length($katashiki1)
	{
		if ($katashiki1 == 'NT') {
			return true;
		}
		return false;
	}

	/**
	 * 寿命計算
	 * 取付姿勢から寿命計算の配置図の画像キーを返す
	 */
	public static function conv_haichi_img_key($t0017)
	{
		$img_key = '';
		
		if ($t0017 == 'S0001') {
			$img_key = 'I0002';
		} else if ($t0017 == 'S0002') {
			$img_key = 'I0003';
		} else if ($t0017 == 'S0003') {
			$img_key = 'I0004';
		}
		
		return $img_key;
	}

	/**
	 * 寿命計算
	 * 取付姿勢から寿命計算の配置図の言語キーを返す
	 */
	public static function conv_haichi_lang_key($t0017)
	{
		$lang_key = '';
		
		if ($t0017 == 'S0001') {
			$lang_key = 'T0128';
		} else if ($t0017 == 'S0002') {
			$lang_key = 'T0170';
		} else if ($t0017 == 'S0003') {
			$lang_key = 'T0174';
		}
		
		return $lang_key;
	}

	/**
	 * 寿命計算
	 * 取付姿勢から質量のチェック値のキーを返す
	 */
	public static function conv_shitsuryo_check_key($t0017)
	{
		$check_key = '';
		
		if ($t0017 == 'S0001') {
			$check_key = 'SUIHEI_MAX_SHITSURYO';
		} else if ($t0017 == 'S0002') {
			$check_key = 'SUICHOKU_MAX_SHITSURYO';
		} else if ($t0017 == 'S0003') {
			$check_key = 'SUIHEI_MAX_SHITSURYO';
		}
		
		return $check_key;
	}

	/**
	 * 小数点変換（入力値表示）
	 */
	public static function conv_dec_in($value)
	{
		$tmp = self::_conv_dec_com($value);
		$tmp = number_format($tmp, 7, '.', ',');
		// 0.000→0.0
		$tmp = preg_replace('/\.?0+$/', '', $tmp);
		return $tmp;
	}

	/**
	 * 小数点変換（計算結果表示）
	 * 少数部は1桁のみ表示
	 */
	public static function conv_dec($value)
	{
		$tmp = self::_conv_dec_com($value);
		// 変換
		return number_format(sprintf('%01.1f', $tmp), 1, '.', ',');
	}

	/**
	 * 小数点変換（計算途中PDF表示）
	 * 0 をつけるだけ
	 */
	public static function conv_dec_calcpdf($value)
	{
		$tmp = self::_conv_dec_com($value);
		return $tmp;
	}

	/**
	 * 小数点変換（共通）
	 */
	private static function _conv_dec_com($value)
	{
		$tmp = $value;
		// .01→0.01
		if (substr($tmp, 0, 1) === '.') {
			$tmp = '0' . $tmp;
		}
		if (substr($tmp, 0, 2) === '-.') {
			$tmp = str_replace('-.', '-0.', $tmp);
		}
		
		return $tmp;
	}

	/**
	 * 数値変換（計算結果表示）
	 */
	public static function conv_num($value)
	{
		// 少数部は切り捨て
		$int_val = floor($value);
		// 万の桁(5桁)まではそのまま表示
		$vlen = mb_strlen($int_val);
		if ($vlen <= 5) {
			return number_format($int_val);
		}
		// 変換
		return sprintf('%.2E', $int_val);
	}
}
