<?php
/**
 * プロジェクト用定義クラス
 */
class Dfn
{
	// メインエリアの最低高さ
	const MAIN_MIN_HEIGHT = 563;

	// 言語コード
	const LANG_CD_JPN = 'jp';
	const LANG_CD_ENG = 'en';
	const LANG_CD_CHN = 'cn';
	const LANG_CD_KOR = 'kr';

	// 言語コード(<タグ名 lang=lang> に使用する)
	const LANG_CD_TAG_JPN = 'ja';
	const LANG_CD_TAG_ENG = 'en';
	const LANG_CD_TAG_CHN = 'zh';
	const LANG_CD_TAG_KOR = 'ko';

	// 含む
	const CONDITION_LIKE = 'like';
	// 等しい
	const CONDITION_EQUAL = 'equal';
	// IN
	const CONDITION_IN = 'in';

	// 無記号
	const YB_KEY_NO_SYMBOL = 'NO SYMBOL';
	const YB_VAL_NO_SYMBOL = '　';

	// 型式検索MAX値
	const MAX_VAL_STROKE = 2670;
	const MAX_VAL_KAKUDO = 280;
	const MAX_VAL_SOKUDO = 3000;
	const MAX_VAL_TOSAI_SHITSURYO = 536;

	// 50％維持用画像パス
	const HOLD_IMG_PATH = 'tool/images/02.png';

	// 寿命計算の係数デフォルト値
	const KAJU_KEISU_DEFAULT = 1.5;
	// 寿命計算の係数手動入力値
	const KAJU_KEISU_USER_IN = '*';

	// 寿命計算 注意表示の加速度値（10G = 98.0665m/s2）
	const WARNING_KASOKUDO = 98.0665;

	// 寿命計算 取付姿勢画像のMAX値
	const DISP_IMG_MAX_W_TORITSUKE = 500;
	const DISP_IMG_MAX_H_TORITSUKE = 400;

	// 寿命計算 配置画像のMAX値
	const DISP_IMG_MAX_W_HAICHI = 550; // 450;
	const DISP_IMG_MAX_H_HAICHI = 550; // 350;

	// PDFロゴ画像パス
	const PDF_LOGO_IMG_PATH = 'tool/images/IKO_LOGO.png';
	
	const SESSION_LOGIN_TIMEOUT = 1800; // secon
	//Add Start IKO_VN-1 hungtn VNIT 20170725
	const SCREEN_DEFINE = array(
		'login_model' =>array(
			'action_logout' => '「ログアウト」',
		 	'action_checklogin' => 'ログイン 「Login」'
		 ),
		'dashboard_model' =>array('action_index' => '管理画面'),
		'csv_model' =>array(
			'action_index' => '管理画面 「ログ出力」',
			'action_download' => 'ログ出力  「出力」'
		),
		'user_model' => array(
			'action_index' => 'list user',
			'action_add' => 'add new user',
			'action_update' => 'update user'
		)
	);//Add End IKO_VN-1 hungtn VNIT 20170725
	
	const CSV_ACTION_LOG_FILENAME = 'mechatronics_log.csv';//Add IKO_VN-2 Screen export csv MinhVnit 20170725
	const LOG_USER_ACTION_FLG = true; // Add IKO_VN-1 hungtn VNIT 20170725
}