<?php
/**
 * コンフィグファイル
 */

// システム
// define('APP_TITLE', 'メカトロサイト');
define('APP_COPYRIGHT', 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxx');

define('RJ256_IV', '1da393a0bbb5519c499d4bcad0a9be00');
define('RJ256_KEY', '1da393a0bbb5519c499d4bcad0a9be00');
define('AKAGANE_SALT', 'akg1$%');//IKO_VN-1 ADD HUNG 10/7/2017

require_once(ACW_USER_CONFIG_DIR . '/defines.php');

if (isset($_SERVER['HTTP_HOST'])) {
	if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
		define('ACW_BASE_URL', 'https://' . $_SERVER['HTTP_HOST'] . '/mecha-admin/');
		define('STATIC_BASE_URL', 'https://' . $_SERVER['HTTP_HOST'] . '/mecha-admin/');
	} else {
		define('ACW_BASE_URL', 'http://' . $_SERVER['HTTP_HOST'] . '/mecha-admin/');
		define('STATIC_BASE_URL', 'http://' . $_SERVER['HTTP_HOST'] . '/mecha-admin/');
	}
}

//define('STATIC_BASE_URL', 'https://www.iko-mechazumen.com/mecha/');

// ログイン認証API
define('API_LOGIN', 'https://ikowb01.ikont.co.jp/technicalservice/auth.php');

// DB
define('DB_DSN', 'sqlsrv:server=localhost\ADMIN;Database=mecha-tool');
define('DB_USERNAME', 'sa');
define('DB_PASSWORD', '123456');

// エラー
define('ERROR_SEND_MAIL', false); // エラーメールなし
error_reporting(-1); // 出力あり


//// エラーメール差出人
//define('ERROR_MAIL_FROM', '---@argo-inc.co.jp');
//// エラーメール差出人名
//define('ERROR_MAIL_FROM_NAME', '---');
//// エラーメール送信先
//define('ERROR_MAIL_TO', '---@---');
//// エラーメール件名
//define('ERROR_MAIL_SUBJECT', '【システムメール】---でエラーが発生しました');
//
//define('ERROR_SMTP_SERVER', 'wx05.wadax.ne.jp');			// SMTP サーバ
//define('ERROR_SMTP_SERVER_PORT', '587');					// SMTP サーバ
//define('ERROR_SMTP_SERVER_ACCOUNT', '---@argo-inc.co.jp');	// SMTP サーバアカウント
//define('ERROR_SMTP_SERVER_PASSWORD', '---');			// SMTP サーバパスワード
