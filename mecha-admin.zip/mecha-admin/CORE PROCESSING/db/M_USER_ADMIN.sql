/*
Navicat SQL Server Data Transfer

Source Server         : localhost
Source Server Version : 100000
Source Host           : .\sqlexpress:1433
Source Database       : iko
Source Schema         : dbo

Target Server Type    : SQL Server
Target Server Version : 100000
File Encoding         : 65001

Date: 2017-07-20 13:57:42
*/


-- ----------------------------
-- Table structure for M_USER_ADMIN
-- ----------------------------
DROP TABLE [dbo].[M_USER_ADMIN]
GO
CREATE TABLE [dbo].[M_USER_ADMIN] (
[M_NUMBER] int NOT NULL IDENTITY(1,1) ,
[USER_ID] varchar(10) NOT NULL ,
[PASSWORD] varchar(100) NOT NULL ,
[USER_NM] varchar(100) NOT NULL ,
[USER_LEVEL_ID] int NOT NULL ,
[DELETE_FLG] bit NOT NULL DEFAULT ((0)) ,
[INS_USER_ID] int NOT NULL ,
[INS_TS] datetime2(7) NOT NULL DEFAULT (getdate()) ,
[UPD_USER_ID] int NOT NULL ,
[UPD_TS] datetime2(7) NOT NULL DEFAULT (getdate()) 
)


GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'M_USER_ADMIN', 
'COLUMN', N'M_NUMBER')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'ユーザマスタ一意ID '
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'M_USER_ADMIN'
, @level2type = 'COLUMN', @level2name = N'M_NUMBER'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'ユーザマスタ一意ID '
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'M_USER_ADMIN'
, @level2type = 'COLUMN', @level2name = N'M_NUMBER'
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'M_USER_ADMIN', 
'COLUMN', N'USER_ID')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'ユーザID'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'M_USER_ADMIN'
, @level2type = 'COLUMN', @level2name = N'USER_ID'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'ユーザID'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'M_USER_ADMIN'
, @level2type = 'COLUMN', @level2name = N'USER_ID'
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'M_USER_ADMIN', 
'COLUMN', N'PASSWORD')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'パスワード'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'M_USER_ADMIN'
, @level2type = 'COLUMN', @level2name = N'PASSWORD'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'パスワード'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'M_USER_ADMIN'
, @level2type = 'COLUMN', @level2name = N'PASSWORD'
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'M_USER_ADMIN', 
'COLUMN', N'USER_NM')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'ユーザ名 '
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'M_USER_ADMIN'
, @level2type = 'COLUMN', @level2name = N'USER_NM'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'ユーザ名 '
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'M_USER_ADMIN'
, @level2type = 'COLUMN', @level2name = N'USER_NM'
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'M_USER_ADMIN', 
'COLUMN', N'USER_LEVEL_ID')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'ユーザレベルID'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'M_USER_ADMIN'
, @level2type = 'COLUMN', @level2name = N'USER_LEVEL_ID'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'ユーザレベルID'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'M_USER_ADMIN'
, @level2type = 'COLUMN', @level2name = N'USER_LEVEL_ID'
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'M_USER_ADMIN', 
'COLUMN', N'DELETE_FLG')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'削除フラグ'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'M_USER_ADMIN'
, @level2type = 'COLUMN', @level2name = N'DELETE_FLG'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'削除フラグ'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'M_USER_ADMIN'
, @level2type = 'COLUMN', @level2name = N'DELETE_FLG'
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'M_USER_ADMIN', 
'COLUMN', N'INS_USER_ID')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'登録ユーザID'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'M_USER_ADMIN'
, @level2type = 'COLUMN', @level2name = N'INS_USER_ID'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'登録ユーザID'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'M_USER_ADMIN'
, @level2type = 'COLUMN', @level2name = N'INS_USER_ID'
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'M_USER_ADMIN', 
'COLUMN', N'INS_TS')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'登録日時'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'M_USER_ADMIN'
, @level2type = 'COLUMN', @level2name = N'INS_TS'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'登録日時'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'M_USER_ADMIN'
, @level2type = 'COLUMN', @level2name = N'INS_TS'
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'M_USER_ADMIN', 
'COLUMN', N'UPD_USER_ID')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'更新ユーザID'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'M_USER_ADMIN'
, @level2type = 'COLUMN', @level2name = N'UPD_USER_ID'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'更新ユーザID'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'M_USER_ADMIN'
, @level2type = 'COLUMN', @level2name = N'UPD_USER_ID'
GO
IF ((SELECT COUNT(*) from fn_listextendedproperty('MS_Description', 
'SCHEMA', N'dbo', 
'TABLE', N'M_USER_ADMIN', 
'COLUMN', N'UPD_TS')) > 0) 
EXEC sp_updateextendedproperty @name = N'MS_Description', @value = N'更新日時'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'M_USER_ADMIN'
, @level2type = 'COLUMN', @level2name = N'UPD_TS'
ELSE
EXEC sp_addextendedproperty @name = N'MS_Description', @value = N'更新日時'
, @level0type = 'SCHEMA', @level0name = N'dbo'
, @level1type = 'TABLE', @level1name = N'M_USER_ADMIN'
, @level2type = 'COLUMN', @level2name = N'UPD_TS'
GO

-- ----------------------------
-- Indexes structure for table M_USER_ADMIN
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table M_USER_ADMIN
-- ----------------------------
ALTER TABLE [dbo].[M_USER_ADMIN] ADD PRIMARY KEY ([M_NUMBER])
GO
