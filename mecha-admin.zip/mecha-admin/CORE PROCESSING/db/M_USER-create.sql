CREATE TABLE M_USER (
	M_USER_ID int NOT NULL IDENTITY,
    USER_ID varchar(250) NOT NULL,
    USER_NAME varchar(250) NOT NULL,
    PASS varchar(250),
    EMAIL_ADDRESS varchar(250),
	DEL_FLG int NOT NULL,
    INS_USER_ID int,
    INS_TS DATETIME2 NOT NULL,
	UPD_USER_ID int,
	UPD_TS DATETIME2 NOT NULL,
    PRIMARY KEY (M_USER_ID)
)
INSERT INTO [dbo].[M_USER]
           ([USER_ID]
           ,[USER_NAME]
           ,[PASS]
           ,[EMAIL_ADDRESS]
           ,[DEL_FLG]
           ,[INS_USER_ID]
           ,[INS_TS]
           ,[UPD_USER_ID]
           ,[UPD_TS])
     VALUES
           ('test'
           ,'test'
		   ,CONVERT(VARCHAR(32), HashBytes('MD5', 'akg1$%admin'), 2)
           ,'email@gmail.com'
           ,0
           ,0
           ,'2016-12-21 00:00:00.0000000'
           ,0
           ,'2016-12-21 00:00:00.0000000');