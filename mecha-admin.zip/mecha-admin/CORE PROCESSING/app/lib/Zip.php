<?php
/**
 * zip操作ライブラリ
 * （Directory_libが必要です）
 */
class Zip_lib
{
	/**
	 * フォルダごとZIPにする
	 *
	 * @param	string	ZIPにするフォルダ
	 * @param	string	ZIPの保存先パス
	 * @return	boolean	成功時:true、失敗時:false
	 */
	public static function compress_dir($dir, $zip_path)
	{
		// フォルダ内のファイル一覧を取得
		$files = Directory_lib::get_file_list($dir);
		if (empty($files)) {
			return false;
		}

		// 保存先フォルダがない場合、作成する
		$zip_dir = dirname($zip_path);
		if (! is_dir($zip_dir)) {
			mkdir($zip_dir, 0777, true);
		}

		// ZIPオープン
		$za = new ZipArchive();
		$res = $za->open($zip_path, ZIPARCHIVE::CREATE | ZIPARCHIVE::OVERWRITE);
		if (! $res) {
			return false;
		}

		// ZIPの中にファイルを追加する
		foreach($files as $file){
			$za->addFile($dir . '/' . $file, $file);
		}

		return $za->close();
	}
}
