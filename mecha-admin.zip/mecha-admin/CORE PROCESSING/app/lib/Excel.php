<?php
set_time_limit(0);
require_once(ACW_VENDOR_DIR . '/phpexcel/PHPExcel.php');
require_once(ACW_VENDOR_DIR . '/phpexcel/PHPExcel/IOFactory.php');

/**
 * Excelライブラリ（抽象クラス）
 */
abstract class Excel_lib
{
	// Excel 2003以前の形式
	const EXCEL2003 = 'Excel5';

	// Excel 2007以降の形式
	const EXCEL2007 = 'Excel2007';

	// ファイル形式
	protected $_filetype;

	// ブック
	protected $_book = null;

	// シート
	protected $_sheet = null;

	/**
	 * コンストラクタ
	 */
	public function __construct($filetype = self::EXCEL2003)
	{
		$this->_filetype = $filetype;

		// メモリ不足を解消するため、キャッシュをファイルにする
		PHPExcel_Settings::setCacheStorageMethod(
			PHPExcel_CachedObjectStorageFactory::cache_to_discISAM
		,	array('dir' => ACW_TMP_DIR . '/excel_cache')
		);
	}

	/**
	 * シャットダウン設定
	 */
	public function set_shutdown_method($method_name, $param = null)
	{
		register_shutdown_function(array($this, $method_name), $param);
	}

	/**
	 * 読み込み
	 */
	public function load($file_path)
	{
		$reader = PHPExcel_IOFactory::createReader($this->_filetype);
		$this->_book = $reader->load($file_path);
	}

	/**
	 * メモリを解放する
	 */
	public function free()
	{
		if (isset($this->_book)) {
			try {
				// メモリ解放
				$this->_book->disconnectWorksheets();
				unset($this->_book);
				$this->_book = null;
			} catch (Exception $e) {
				ACWLog::write_file('EXCELERROR', $e->getMessage());
			}
		}
	}

	/**
	 * エクセルOPEN
	 */
	public function open($file_name)
	{
		$reader = PHPExcel_IOFactory::createReader($this->_filetype);
		$this->_book = $reader->load($file_name);
		$this->active_worksheet(0);
	}

	/**
	 * エクセルCLOSE
	 */
	public function close($file_name)
	{
		$writer = PHPExcel_IOFactory::createWriter($this->_book, $this->_filetype);
		$writer->save($file_name);
		$this->free();
	}

	/**
	 * ワークシート選択
	 */
	public function active_worksheet($sheet_index)
	{
		$this->_sheet = $this->_book->getSheet($sheet_index);
		$this->_book->setActiveSheetIndex($sheet_index);
	}

	/**
	 * Excelセル名へ変換（0,1 → A1）
	 */
	public function get_colname($x, $y)
	{
		return PHPExcel_Cell::stringFromColumnIndex($x) . $y;
	}

	/**
	 * 書式設定
	 */
	public function set_format($range, $format_string)
	{
		//$rangeには'E1:E256'等の範囲
		$this->_sheet->getStyle($range)->getNumberFormat()->setFormatCode($format_string);
	}

	/**
	 * メモリ使用量ログ出力
	 */
	public function write_use_memory_log($out_excel_name)
	{
		ACWLog::write_file('EXCEL_MEMORY', $out_excel_name . ' 使用量 : ' . number_format(memory_get_usage()) . PHP_EOL);
		ACWLog::write_file('EXCEL_MEMORY', $out_excel_name . ' 割当量 : ' . number_format(memory_get_peak_usage(true)) . PHP_EOL);
	}

	/**
	 * セルに値を設定
	 * @param	integer	縦軸
	 * @param	integer	横軸
	 * @param	mixed	値
	 */
	public function _val($x, $y, $value)
	{
		if (strlen($value)) {
			$this->_sheet->setCellValueByColumnAndRow($x - 1, $y, $value);
		}
	}
	public function _str($x, $y, $value)
	{
		if (strlen($value)) {
			$this->_sheet->setCellValueExplicitByColumnAndRow($x - 1, $y, $value, PHPExcel_Cell_DataType::TYPE_STRING);
		}
	}
	public function _num($x, $y, $value)
	{
		if (strlen($value)) {
			$this->_sheet->setCellValueExplicitByColumnAndRow($x - 1, $y, $value, PHPExcel_Cell_DataType::TYPE_NUMERIC);
		}
	}
	public function _fnc($x, $y, $value)
	{
		if (strlen($value)) {
			$this->_sheet->setCellValueExplicitByColumnAndRow($x - 1, $y, $value, PHPExcel_Cell_DataType::TYPE_FORMULA);
		}
	}

	/**
	 * 行非表示
	 * @param	integer	開始行
	 * @param	integer	終了行
	 */
	public function _hide_row($fr_y, $to_y)
	{
		for ($i = $fr_y; $i <= $to_y; $i++) {
			$this->_sheet->getRowDimension($i)->setVisible(false);
		}
	}

	/**
	 * 枠線の範囲設定
	 * @param	string	横のセル開始位置
	 * @param	string	縦のセル終了位置
	 * @param	string	横のセル開始位置
	 * @param	string	縦のセル終了位置
	 * @param	string	枠線スタイル
	 */
	public function _set_border_range($sx, $sy, $ex, $ey, $border = PHPExcel_Style_Border::BORDER_THIN)
	{
		$this->_sheet->getStyle(
			self::get_colname($sx - 1, $sy) . ':' . self::get_colname($ex - 1, $ey)
		)->getBorders()->getAllBorders()->setBorderStyle($border);
	}

	/**
	 * 太字
	 * @param	string	横のセル開始位置
	 * @param	string	縦のセル終了位置
	 * @param	string	横のセル開始位置
	 * @param	string	縦のセル終了位置
	 * @param	string	枠線スタイル
	 */
	public function _set_bold($sx, $sy, $ex = null, $ey = null)
	{
		$to = (is_null($ex) || is_null($ey)) ? '' : ':' . self::get_colname($ex - 1, $ey);
		$this->_sheet->getStyle(
			self::get_colname($sx - 1, $sy) . $to
		)->getFont()->setBold(true);
	}

	/**
	 * 背景色
	 * @param	string	背景色
	 * @param	string	横のセル開始位置
	 * @param	string	縦のセル終了位置
	 * @param	string	横のセル開始位置
	 * @param	string	縦のセル終了位置
	 */
	public function _set_bgcolor($color, $sx, $sy, $ex = null, $ey = null)
	{
		$to = (is_null($ex) || is_null($ey)) ? '' : ':' . self::get_colname($ex - 1, $ey);
		$this->_sheet->getStyle(
			self::get_colname($sx - 1, $sy) . $to
		)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB($color);
	}

	/**
	 * 中央寄せ
	 * @param	string	横のセル開始位置
	 * @param	string	縦のセル終了位置
	 * @param	string	横のセル開始位置
	 * @param	string	縦のセル終了位置
	 */
	public function _align_center($sx, $sy, $ex = null, $ey = null)
	{
		$to = (is_null($ex) || is_null($ey)) ? '' : ':' . self::get_colname($ex - 1, $ey);
		$this->_sheet->getStyle(
			self::get_colname($sx - 1, $sy) . $to
		)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
	}

	/**
	 * 右寄せ
	 * @param	string	横のセル開始位置
	 * @param	string	縦のセル終了位置
	 * @param	string	横のセル開始位置
	 * @param	string	縦のセル終了位置
	 */
	public function _align_right($sx, $sy, $ex = null, $ey = null)
	{
		$to = (is_null($ex) || is_null($ey)) ? '' : ':' . self::get_colname($ex - 1, $ey);
		$this->_sheet->getStyle(
			self::get_colname($sx - 1, $sy) . $to
		)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
	}

	/**
	 * 右寄せ
	 * @param	string	横のセル開始位置
	 * @param	string	縦のセル終了位置
	 * @param	string	横のセル開始位置
	 * @param	string	縦のセル終了位置
	 */
	public function _align_left($sx, $sy, $ex = null, $ey = null)
	{
		$to = (is_null($ex) || is_null($ey)) ? '' : ':' . self::get_colname($ex - 1, $ey);
		$this->_sheet->getStyle(
			self::get_colname($sx - 1, $sy) . $to
		)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
	}

	/**
	 * 縮小して全体を表示する
	 * @param	string	横のセル開始位置
	 * @param	string	縦のセル終了位置
	 * @param	string	横のセル開始位置
	 * @param	string	縦のセル終了位置
	 */
	public function _set_shukusho($sx, $sy, $ex = null, $ey = null)
	{
		$to = (is_null($ex) || is_null($ey)) ? '' : ':' . self::get_colname($ex - 1, $ey);
		$this->_sheet->getStyle(
			self::get_colname($sx - 1, $sy) . $to
		)->getAlignment()->setShrinkToFit(true);
	}
}
/* ファイルの終わり */