<?php
/**
 * ページャーライブラリ
 */
class Pager_lib
{
	/**
	 * ページ番号名
	 */
	const NAME = 'page';

	/**
	 * 表示ページリンク数
	 */
	public static $MAX_LINK = 10;

	/**
	 * クエリの区切り文字（必ず配列３つで指定すること）
	 * 0: 文字があれば、クエリ全体の左側に付加
	 * 1: 引数１つ１つの区切り文字
	 * 2: 文字があれば、クエリ全体の右側に付加
	 */
	public static $QUERY_SEPARATORS = array('&amp;', '&amp;', '');

	/**
	 * クエリ上書き用の配列
	 */
	public static $MERGE_QUERY = array();

	/**
	 * ページャー作成用のデータを返す
	 * （返したデータをもとにview処理で表示）
	 *
	 * @param	integer	表示するページ番号
	 * @param	integer	1ページにつき表示する件数
	 * @param	integer	総件数
	 * @return	array	ページャー作成用データ
	 */
	public static function get_data($current_page, $per_page, $total_rows)
	{
		if (! self::_check()) {
			die('Pager Setting Error.');
		}

		$current_page = max(1, (int)$current_page);
		$per_page     = max(1, (int)$per_page);

		// ページ総数
		$total_pages = max(1, (int)(string)ceil($total_rows / $per_page));
		if ($total_pages < 2) {
			//return null;
			$total_pages = 1;
		}

		// 表示ページ範囲の取得
		list($start, $end) = self::_get_range($current_page, $per_page, $total_pages);

		// URL用のクエリ作成（エンコード済）
		$url_query = null;//self::build_query();

		return array(
			'param_name'   => self::NAME,
			'current_page' => $current_page,
			'total_pages'  => $total_pages,
			'start'        => $start,
			'end'          => $end,
			'url_query'    => $url_query,
		);
	}

	/**
	 * URL用のクエリ作成
	 *
	 * @param	array	クエリに使用しないKEY
	 * @return	string	URL用のクエリ
	 */
	public static function build_query($unsets = null)
	{
		if (! isset($_SERVER['QUERY_STRING'])) {
			return '';
		}

		$ary = array();
		parse_str($_SERVER['QUERY_STRING'], $ary);
		unset($ary[ACWCore::get_config('url_cmd')]); // システム用変数の撤去
		unset($ary[self::NAME]); // ページ番号の撤去
		if (is_array($unsets)) {
			foreach ($unsets as $name) {
				unset($ary[$name]); // 指定したKEYで撤去
			}
		}

		if (is_array(self::$MERGE_QUERY)) {
			$ary = array_merge($ary, self::$MERGE_QUERY);
		}
		foreach ($ary as $key => $val) {
			if (strlen($val) === 0) {
				unset($ary[$key]); // リクエストのない引数の撤去
			}
		}

		return empty($ary) ? '' :
			self::$QUERY_SEPARATORS[0] .
			http_build_query($ary, '', self::$QUERY_SEPARATORS[1]) .
			self::$QUERY_SEPARATORS[2];
	}

	/**
	 * 設定チェック
	 *
	 * @return	boolean true:OK
	 */
	private static function _check()
	{
		if (! is_int(self::$MAX_LINK)) {
			return false;
		}
		if (self::$MAX_LINK <= 1) {
			return false;
		}
		if (! is_array(self::$QUERY_SEPARATORS)) {
			return false;
		}
		if (count(self::$QUERY_SEPARATORS) !== 3) {
			return false;
		}
		return true;
	}

	/**
	 * 表示ページ範囲を返す
	 *
	 * @param	integer	表示するページ番号
	 * @param	integer	1ページにつき表示する件数
	 * @param	integer	ページ総数
	 * @return	array	0 => 開始ページ、1 => 終了ページ
	 */
	private static function _get_range($current_page, $per_page, $total_pages)
	{
		// 開始ページ
		$start = $current_page - (int)(string)floor(self::$MAX_LINK * 0.49);

		// 終了ページ
		$end   = $current_page + (int)(string)floor(self::$MAX_LINK * 0.51);

		// ページ調整
		if ($start < 1) {
			$end -= $start - 1;
			$start = 1;
		}
		if ($end < $current_page) {
			$start++;
			$end++;
		}
		if ($total_pages < $end) {
			$start = max(1, $start - $end + $total_pages);
			$end = $total_pages;
		}

		return array($start, $end);
	}
}
