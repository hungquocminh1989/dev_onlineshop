<?php
set_time_limit(0);

require_once ACW_VENDOR_DIR . '/jphpmailer/jphpmailer.php';  //ライブラリ読み込み

/**
 * エラーメール送信クラス
 */
class ErrorMailer_lib {
	public function send($mail_body)
	{
		mb_language('japanese');  // 言語(日本語)
		$mail = new JPHPMailer(); // JPHPMailerのインスタンス生成

		$mail->IsSMTP();                                                    // SMTPサーバーを使う設定
		$mail->SMTPAuth = TRUE;                                             // SMTP認証を使う設定
		$mail->Host     = ERROR_SMTP_SERVER . ':' . ERROR_SMTP_SERVER_PORT; // SMTPサーバーアドレス:ポート番号
		$mail->Username = ERROR_SMTP_SERVER_ACCOUNT;                        // SMTP認証用のユーザーID
		$mail->Password = ERROR_SMTP_SERVER_PASSWORD;                       // SMTP認証用のパスワード

		$mail->addTo(ERROR_MAIL_TO);                            // 宛先(To)をセット
		$mail->setFromJ(ERROR_MAIL_FROM, ERROR_MAIL_FROM_NAME); // 差出人(From/From名)をセット
		$mail->setSubject(ERROR_MAIL_SUBJECT);                  // 件名(Subject)をセット
		$mail->setBody($mail_body);                             // 本文(Body)をセット

		if (! $mail->send()){
			// メール送信エラー
			ACWLog::write_file('MAIL_ERROR', $mail->getErrorMessage());
		}
	}
}
