<?php
/**
 * 乱数
 */
class Random_lib
{
	/**
	 * 問い合わせに対応するID
	 */
	public static function get_query_id()
	{
		$mtime = str_replace(' ', '', microtime());
		$today = new DateTime();
		return $today->format('YmdHis') . substr($mtime, 2, 3) . sprintf('%03d', mt_rand(0, 999));
	}
}

/* ファイルの終わり */