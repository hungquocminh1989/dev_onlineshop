<?php
/**
 * 暗号ライブラリ（RJ256)
 */
class RJ256_lib
{
	/**
	 * 暗号化
	 *
	 * @param	string	プレーンテキスト文字列
	 * @return	string	暗号化文字列
	 */
	static function encrypt($string_to_encrypt)
	{
		$rtn = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, RJ256_KEY, $string_to_encrypt, MCRYPT_MODE_CBC, RJ256_IV);
		$rtn = base64_encode($rtn);
		return($rtn);
	}

	/**
	 * 複合化	 *
	 * @param	string	暗号化文字列
	 * @return	string	プレーンテキスト文字列
	 */
	static function decrypt($string_to_decrypt)
	{
		$string_to_decrypt = base64_decode($string_to_decrypt);
		$rtn = mcrypt_decrypt(MCRYPT_RIJNDAEL_256, RJ256_KEY, $string_to_decrypt, MCRYPT_MODE_CBC, RJ256_IV);
		$rtn = rtrim($rtn, "\x00");
		return($rtn);
	}
}
