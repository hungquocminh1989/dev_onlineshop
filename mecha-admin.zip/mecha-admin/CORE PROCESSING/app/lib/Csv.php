<?php

/**
 * CSV入出力ライブラリ
 */
class Csv_lib
{
	protected $fp;				// ファイルポインタ
	protected $nextCSVLine;		// 次はCSVが何行目か
	protected $orgDataBuf;		// sjisの読み込みバッファ
	protected $utf8buf;			// utf8に変換したバッファ
	protected $fieldName;		// 項目名
	protected $eofFlag;			// EOF

	const CSV_READ_LENGTH	 = 32;
	const CSV_SPLIT_CHAR	 = ","; // CSV区切り
	const SJIS_CRLF			 = "\r\n";

	/////////////////////////////////////////////////////////////////////////
	// 書き出し
	/////////////////////////////////////////////////////////////////////////

	// CSV出力
	public static function output($data, $filename, $header, $output_header=true)
	{
		if (($fp = @fopen($filename, 'w')) === false) {
			return;
		}

		if (//count($data) > 0 && //Delete Minh 20170724  (CSV không có data thì ra file chỉ có header)
			$output_header == true) {
			$col_list = array();
			// ヘッダの出力
			foreach ($header as $hdr) {
				$col_list[] = $hdr['title'];
			}
			self::output_line($fp, $col_list);
		}

		// データ出力
		foreach ($data as $row) {
			$col_list = array();
			// 一行の出力
			foreach ($header as $hdr) {
				$column = $hdr['column'];
				$col_list[] = self::make_column($row[$column]);
			}
			self::output_line($fp, $col_list);
		}
		@fclose($fp);
	}

	// CSV出力の際にひとつの列を出力
	protected static function make_column($val)
	{
		if (is_null($val)) {
			return '';
		}

		// 改行統一
		$val = str_replace(array("\r\n","\r"), "\n", $val);
		// カンマかタブかダブルクォーテーションが含まれていない
		if (strpos($val, "\"") === false) {
			if (strpos($val, ",") === false && strpos($val, "\t") === false && strpos($val, "\n") === false) {
				return '"' . $val . '"';//Edit MinhVnit 20170727
			} else {
				return '"' . $val . '"';
			}
		}
		// 置換
		return '"' . str_replace('"', '""', $val) . '"';
	}

	// CSV出力の際にひとつの列を出力
	protected static function output_line($fp, $column_list)
	{
		$buf = implode(',', $column_list);
		@fwrite($fp, mb_convert_encoding($buf, 'SJIS-win', 'utf-8') .  "\r\n");
	}

	/////////////////////////////////////////////////////////////////////////
	// 読み込み
	/////////////////////////////////////////////////////////////////////////

	public function open($logcsv, $convertName=null, $is_exist_top = true)
	{
		// 初期化
		$this->orgDataBuf = '';
		$this->utf8buf = '';
		$this->nextCSVLine = 1;
		$this->eofFlag = false;

		$this->fp = fopen($logcsv, 'rb');
		if ($this->fp === false) {
			return -1;	// ファイルオープン失敗
		}

		// 項目名を読み込む
		$topLine = null;
		if ($is_exist_top) {
			$topLine = $this->read1LineData($eof);
		}
		if (is_array($convertName)) {
			$this->fieldName = array();
			foreach ($convertName as $cName) {
				$this->fieldName[] = $cName;
			}
		}
		if (empty($this->fieldName)) {
			$this->fieldName = $topLine;
		}

		return 0;
	}

	public function close()
	{
		fclose($this->fp);
	}

	// 一行データ読み込み
	// パラメタの$lineと$eofは出力
	public function &read1Line(&$line, &$eof)
	{
		// データ読み込み
		$dataArray = $this->read1LineData($eof);
		// 行数
		$line = $this->nextCSVLine - 1;
		if ($eof == true) {
			return $dataArray;
		}
		$resultArray = array();
//		$max = count($this->fieldName);
//		for ($i = 0; $i < $max; $i ++) {
//			$key = $this->fieldName[$i];
//			$resultArray[$key] = $dataArray[$i];
//		}
		if (count($this->fieldName) !== count($dataArray)) {
			return $dataArray;
		}
		foreach ($dataArray as $i => $val) {
			$key = $this->fieldName[$i];
			$resultArray[$key] = $val;
		}
		return $resultArray;
	}

	// 内部処理
	protected function &read1LineData(&$eof)
	{
		$result = null;	// 結果
		if ($this->eofFlag == true && $this->orgDataBuf == '') {
			// EOFになった
			$eof = true;
			return $result;
		}

		$result = array();
		$dataFull = true;	// データが完全かどうか
		$fieldData = '';
		$currentLine = $this->nextCSVLine;
		$finishChar = '';	// 最終的に終わるキャラクタ
		do {
			// 一行読み込む
			$this->utf8buf .= $this->readLineBuffer();
			for (;;) {
				// CSV一行解析のための区切りループ
				$this->utf8buf = $this->parseCSV($this->utf8buf, $fieldData, $dataFull, $finishChar);
				if ($dataFull == false) {
					break;	// 未解析だがバッファ枯渇
				}
				// データ設定
				$result[] = $fieldData;
				$fieldData = '';
			}
		} while ($currentLine == $this->nextCSVLine);

		return $result;
	}

	protected function parseCSV(&$buf, &$fieldData, &$dataFull, &$finishChar)
	{
		$len = strlen($buf);
		if ($len == 0) {
			$dataFull = false;
			return '';
		}
		if ($dataFull == true) {
			// 完全データ後最初から解析
			if ($buf{0} == '"') {
				$i = 1;
				$finishChar = '"';	// ダブルクォーテーションで終わる
			} else {
				$i = 0;
				$finishChar = self::CSV_SPLIT_CHAR;	// カンマで終わる
			}
		} else {
			// 途中から解析
			$i = 0;
		}

		for (; $i < $len; $i ++) {
			if ($finishChar ==  self::CSV_SPLIT_CHAR) {
				switch($buf{$i}) {
				case "\n":
					// 次の行へ
					$this->nextCSVLine ++;
					// ↓下にスルー
				case self::CSV_SPLIT_CHAR:
					$dataFull = true;	// 完全
					return substr($buf, $i + 1);
				}
			} else if ($finishChar ==  '"' && $buf{$i} == '"') {
				if ($buf{$i + 1} != '"') {
					// エスケープの終わり
					$finishChar = self::CSV_SPLIT_CHAR;
					continue;
				}
				$i ++;	// これは二つのダブルクォーテーション
			}

			$fieldData .= $buf{$i};
		}

		$dataFull = false;	// 不完全
		return '';
	}

	// 改行までを読む
	protected function readLineBuffer()
	{
		for (;;) {
			// 改行位置を探す
			$pos = strpos($this->orgDataBuf, self::SJIS_CRLF);
			if ($pos === false) {
				if ($this->eofFlag == true) {
					// EOFだけど改行がない
					$retbuf = $this->orgDataBuf . self::SJIS_CRLF;
					$this->orgDataBuf = '';
					break;
				}
				// 改行なし
				$this->read();	// 追加読み込み
				continue; // もう一度改行を探す
			} 
			// 改行までをバッファに格納
			$retbuf = substr($this->orgDataBuf, 0, $pos + strlen(self::SJIS_CRLF));
			// 改行以降をとりあえず保存しておく
			$this->orgDataBuf = substr($this->orgDataBuf, $pos + strlen(self::SJIS_CRLF));
			if ($this->orgDataBuf == '') {
				$this->read();	// バッファが空なら次回のために追加読み込み
			}
			break;
		}

		// SJISから変換
		$retbuf = mb_convert_encoding($retbuf, 'UTF-8', 'SJIS-win');
		// 改行コード置換
		return str_replace("\r\n", "\n", $retbuf);
	}

	// 適当な単位で読み込む
	protected function read()
	{
		// 適当な単位で読み込む
		$this->orgDataBuf .= fread($this->fp, self::CSV_READ_LENGTH);
		if (feof($this->fp)) {
			// EOF到達
			$this->eofFlag = true;
		}
	}
}
