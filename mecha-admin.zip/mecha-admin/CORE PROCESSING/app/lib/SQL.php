<?php
/**
 * SQLで使用する
 */
class SQL_lib
{
	/**
	 * LIKEの部分一致
	 * @param	string	編集前
	 * @return	string	編集後
	 */
	public static function like_bubun($text, $asterisk = true)
	{
		return '%' . self::escape_like($text, $asterisk) . '%';
	}

	/**
	 * likeの前方一致
	 * @param	string	編集前
	 * @return	string	編集後
	 */
	public static function like_zenpou($text, $asterisk = true)
	{
		return self::escape_like($text, $asterisk) . '%';
	}

	/**
	 * LIKEの後方一致
	 * @param	string	編集前
	 * @return	string	編集後
	 */
	public static function like_kouhou($text, $asterisk = true)
	{
		return '%' . self::escape_like($text, $asterisk);
	}

	/**
	 * LIKEのエスケープ
	 * @param	string	エスケープ前
	 * @return	string	エスケープ後
	 */
	public static function escape_like($text, $asterisk)
	{
		$wildcards = array('%', '_');
		foreach ($wildcards as $card) {
			//$text = str_replace($card, '\\' . $card, $text);
			$text = str_replace($card, '[' . $card . ']', $text);
		}
		if ($asterisk) {
			$text = str_replace(array('*', '＊'), '_', $text);
		}
		return $text;
	}

	/**
	 * IN句用に配列を編集
	 * @param	array	バインド用データ（参照渡し）
	 * @param	string	編集対象のKEY名
	 * @param	mixed	編集NG時のリターン値
	 * @return	string	SQL文IN句のバインド変数部
	 */
	public static function inku(&$param, $name, $default = null)
	{
		if (empty($param[$name]) || (! is_array($param[$name]))) {
			return $default;
		}

		$ary = array();
		$i = 0;
		foreach ($param[$name] as $val) {
			$key = $name . $i;
			$ary[$i] = $key;
			$param[$key] = $val; // 参照渡しのバインドデータに追加する
			$i++;
		}
		unset($param[$name]);

		return '(:' . implode(', :', $ary) . ')';
	}
}
