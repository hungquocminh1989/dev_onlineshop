<?php
/**
 * エラーチェックライブラリ(名称設定あり)
 */
class Validatename_lib
{
	/**
	 * メッセージを直したい場合は以下を直して下さい
	 */
	const ERR_HISSU = '%sは必須項目です';
	const ERR_ZENKANA = '%sは全角カナで入力してください';
	const ERR_ZENKANASPACE = '%sは全角カナ、スペースで入力してください';
	const ERR_HANKAKUSUUJI = '%sは半角数字で入力してください';
	const ERR_BIGSUUJI = '%sは大きすぎる数値です';
	const ERR_HANISUUJI = '%sは%d～%dの範囲で入力してください';
	const ERR_IJOUSUUJI = '%sは%d以上の数値を入力してください';
	const ERR_IKASUUJI = '%sは%d以下の数値を入力してください';
	const ERR_YMD = '%sはYYYY/MM/DD形式で入力してください';
	const ERR_YM = '%sはYY/MM形式で入力してください';
	const ERR_FUSEI = '%sが正しくありません。';
	const ERR_DATE1900 = '%sに1900年以前の日付は入力できません';
	const ERR_HANKAKUEISUU = '%sは半角英数字で入力してください';
	const ERR_SEISUU = '%sの整数部は%d桁以内で入力してください';
	const ERR_SYOUSUU = '%sの小数部は%d桁以内で入力してください';
	const ERR_MOJIIKA = '%sは%d文字以内で入力してください';
	const ERR_MOJIIJOU = '%sは%d文字以上で入力してください';
	const ERR_MOMJISUU = '%sは%d文字で入力してください';
	const ERR_MOJIIJOUMOJIIKA = '%sは%d文字以上%d文字以内で入力してください';
	const ERR_MOJIIKA_ZENKAKU = '%sは%d文字(全角%d文字)以内で入力してください';
	const ERR_MOJIIJOU_ZENKAKU = '%sは%d文字(全角%d文字)以上で入力してください';
	const ERR_MOMJISUU_ZENKAKU = '%sは%d文字(全角%d文字)で入力してください';
	const ERR_MOJIIJOUMOJIIKA_ZENKAKU = '%sは%d文字以上%d文字以内(全角%d文字以上%d文字以内)で入力してください';
	const ERR_ALLZEN = '%sは全角で入力してください';
	const ERR_ALLHAN = '%sは半角で入力してください';
	const ERR_BUNSU = '%sは半角数字と「/」で入力してください';

	/**
	 * 全角チェック（UTF-8仕様）
	 */
	public function type_zenkaku($key, $name, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $name, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		// 全角チェック
		$v = str_replace(array("\r", "\n"), '', $value); // 改行を取り除く
		if (! preg_match('/^[^ -~｡-ﾟ\x00-\x1f\t]+$/u', $v)) {
			ACWError::add($key, sprintf(self::ERR_ALLZEN, $name));
			return false;
		}

		// 長さチェック
		return $this->_check_length($key, $name, $value, $max, $min);
	}

	/**
	 * 半角チェック（UTF-8仕様）
	 */
	public function type_hankaku($key, $name, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $name, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		// 半角チェック
		if (! preg_match('/^[｡-ﾟｰ !-~]+$/u', $value)) {
			ACWError::add($key, sprintf(self::ERR_ALLHAN, $name));
			return false;
		}

		// 長さチェック
		return $this->_check_length($key, $name, $value, $max, $min);
	}

	/**
	 * 分数チェック
	 */
	public function type_bunsu($key, $name, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $name, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		// 分数チェック
		if (! preg_match('/^[0-9]+(\/[0-9]+)?$/', $value)) {
			ACWError::add($key, sprintf(self::ERR_BUNSU, $name));
			return false;
		}

		// 長さチェック
		return $this->_check_length($key, $name, $value, $max, $min);
	}

	/**
	 * 文字列チェック
	 */
	public function type_str($key, $name, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $name, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		// 長さチェック
		return $this->_check_length($key, $name, $value, $max, $min);
	}

	/**
	 * バイト数チェック
	 */
	public function type_byte($key, $name, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $name, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		// 長さチェック
		return $this->_check_length_byte($key, $name, $value, $max, $min);
	}

	/**
	 * 全角カナ文字列チェック
	 */
	public function zen_kana($key, $name, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $name, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		// 長さチェック
		if ($this->_check_length($key, $name, $value, $max, $min, true) == false) {
			return false;
		}

		// カナのみチェック
		if (! preg_match("/^[ァ-ヶー]+$/u", $value)) {  
			ACWError::add($key, sprintf(self::ERR_ZENKANA, $name));
			return false;
		}
		return true;
	}

	/**
	 * 全角カナ文字列スペースありチェック
	 */
	public function zen_kana_space($key, $name, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $name, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		// 長さチェック
		if ($this->_check_length($key, $name, $value, $max, $min, true) == false) {
			return false;
		}

		// カナチェック
		if (! preg_match("/^[ァ-ヶー　 ]+$/u", $value)) {  
			ACWError::add($key, sprintf(self::ERR_ZENKANASPACE, $name));
			return false;
		}
		return true;
	}

	/**
	 * 数値チェック 最大値　最小値制限
	 */
	public function type_int($key, $name, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $name, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		if (! preg_match('/^-?\d+$/', $value)) {
			ACWError::add($key, sprintf(self::ERR_HANKAKUSUUJI, $name));
			return false;
		}

		if (settype($value, 'integer') == false) {
			ACWError::add($key, sprintf(self::ERR_BIGSUUJI, $name));
			return false;
		}

		if (is_null($min) == false && is_null($max) == false) {
			if ($min > $value || $value > $max) {
				ACWError::add($key, sprintf(self::ERR_HANISUUJI, $name, $min, $max));
				return false;
			}
		}

		if (is_null($min) == false) {
			if ($min > $value) {
				ACWError::add($key, sprintf(self::ERR_IJOUSUUJI, $name, $min));
				return false;
			}
		}

		if (is_null($max) == false) {
			if ($value > $max) {
				ACWError::add($key, sprintf(self::ERR_IKASUUJI, $name, $max));
				return false;
			}
		}

		return true;
	}

	/**
	 * 日付チェック YYYY/MM/DD
	 */
	public function type_ymd($key, $name, $value, $not_null) {
		// NULLチェック
		switch ($this->_check_null($key, $name, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		if (! preg_match('/^\d{4}\/\d{1,2}\/\d{1,2}$/', $value)) {
			ACWError::add($key, sprintf(self::ERR_YMD, $name));
			return false;
		}

		$ary = explode('/', $value);
		if (checkdate($ary[1], $ary[2], $ary[0])) {
			if ((1900 <= $ary[0]) && ($ary[0] <= 2100)) {
				return true;
			}
		}

		ACWError::add($key, sprintf(self::ERR_FUSEI, $name));
		return false;
	}

	/**
	 * 日付チェック YYYY/MM
	 */
	public function type_ym($key, $name, $value, $not_null) {
		// NULLチェック
		switch ($this->_check_null($key, $name, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		if (! preg_match('/^\d{4}\/\d{1,2}$/', $value)) {
			ACWError::add($key, sprintf(self::ERR_YM, $name));
			return false;
		}

		$ary = explode('/', $value);
		if (checkdate($ary[1], 1, $ary[0])) {
			if ((1900 <= $ary[0]) && ($ary[0] <= 2100)) {
				return true;
			}
		}

		ACWError::add($key, sprintf(self::ERR_FUSEI, $name));
		return false;
	}

	/**
	 * 数値または文字列
	 */
	public function alpha_number($key, $name, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $name, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		if (! preg_match("/^[a-zA-Z0-9]+$/", $value)) {
			ACWError::add($key, sprintf(self::ERR_HANKAKUEISUU, $name));
			return false;
		}

		// 長さチェック
		return $this->_check_length($key, $name, $value, $max, $min, false);
	}

	/**
	 * 小数点あり数値
	 */
	public function type_float($key, $name, $value, $not_null, $intNum = null, $decNum = null) {
		// NULLチェック
		switch ($this->_check_null($key, $name, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		if (! preg_match("/^(\d+)(?:\.(\d+))?$/", $value, $match)) {
			ACWError::add($key, sprintf(self::ERR_HANKAKUSUUJI, $name));
			return false;
		}

		if (! is_null($intNum)) {
			if ($intNum < strlen($match[1])) {
				ACWError::add($key, sprintf(self::ERR_SEISUU, $name, $intNum));
				return false;
			}
		}
		if (! is_null($decNum)) {
			if ((isset($match[2]) === true) && ($decNum < strlen($match[2]))) {
				ACWError::add($key, sprintf(self::ERR_SYOUSUU, $name, $decNum));
				return false;
			}
		}

		return true;
	}

	/**
	 * 数字のみ　桁数チェック
	 */
	public function type_number($key, $name, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $name, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		if (! preg_match("/^\d+$/", $value)) {
			ACWError::add($key, sprintf(self::ERR_HANKAKUSUUJI, $name));
			return false;
		}

		// 長さチェック
		return $this->_check_length($key, $name, $value, $max, $min, false);
	}

	/**
	 * 電話番号
	 */
	public function tel($key, $name, $value, $not_null) {
		// NULLチェック
		switch ($this->_check_null($key, $name, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		if (! preg_match("/^0\d{9,10}$/ ", $value)) {
			ACWError::add($key, sprintf(self::ERR_FUSEI, $name));
			return false;
		}

		return true;
	}

	/**
	 * 郵便番号
	 */
	public function post_code($key, $name, $value, $not_null) {
		// NULLチェック
		switch ($this->_check_null($key, $name, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		if (! preg_match("/^\d{7}$/", $value)) {
			ACWError::add($key, sprintf(self::ERR_FUSEI, $name));
			return false;
		}

		return true;
	}

	/**
	 * メール
	 */
	public function mail($key, $name, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $name, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		if (! preg_match("/^[a-zA-Z0-9]+[a-zA-Z0-9\._-]*@[a-zA-Z0-9_-]+\.[a-zA-Z0-9\._-]+$/", $value)) {
			ACWError::add($key, sprintf(self::ERR_FUSEI, $name));
			return false;
		}

		// 長さチェック
		return $this->_check_length($key, $name, $value, $max, $min, false);
	}

	// 長さをチェック
	public function _check_length($key, $name, $value, $max, $min)
	{
		$error_flag = false;
		$vlen = mb_strlen($value);

		if (! is_null($min) && $min > $vlen) {
			$error_flag = true;
		}
		if (! is_null($max) && $max < $vlen) {
			$error_flag = true;
		}

		if ($error_flag == true) {
			if (is_null($min)) {
				ACWError::add($key, sprintf(self::ERR_MOJIIKA, $name, $max));
			} else if (is_null($max)) {
				ACWError::add($key, sprintf(self::ERR_MOJIIJOU, $name, $min));
			} else if ($max == $min) {
				ACWError::add($key, sprintf(self::ERR_MOMJISUU, $name, $max));
			} else {
				ACWError::add($key, sprintf(self::ERR_MOJIIJOUMOJIIKA, $name, $min, $max));
			}
			return false;
		}

		return true;
	}

	// 長さをチェック(バイト数)
	public function _check_length_byte($key, $name, $value, $max, $min)
	{
		$error_flag = false;
		$len = strlen(Enc_lib::u2s($value));

		if (! is_null($min) && $min > $len) {
			$error_flag = true;
		}
		if (! is_null($max) && $max < $len) {
			$error_flag = true;
		}

		if ($error_flag == true) {
			$half_max = floor( $max / 2 );
			$half_min = floor( $min / 2 );

			if (is_null($min)) {
				ACWError::add($key, sprintf(self::ERR_MOJIIKA_ZENKAKU, $name, $max, $half_max));
			} else if (is_null($max)) {
				ACWError::add($key, sprintf(self::ERR_MOJIIJOU_ZENKAKU, $name, $min, $half_min));
			} else if ($max == $min) {
				ACWError::add($key, sprintf(self::ERR_MOMJISUU_ZENKAKU, $name, $max, $half_max));
			} else {
				ACWError::add($key, sprintf(self::ERR_MOJIIJOUMOJIIKA_ZENKAKU, $name, $min, $max, $half_min, $half_max));
			}
			return false;
		}

		return true;
	}

	/////////////////////////////////////////////////////////////////////////
	// 内部関数
	/////////////////////////////////////////////////////////////////////////

	// NULLかどうかの判定
	protected function _is_null($value) {
		if (is_null($value)) {
			return true;
		}
		if (! is_string($value)) {
			settype($value, "string");
		}
		if ($value == '') {
			return true;
		}
		return false;
	}

	protected function _check_null($key, $name, $value, $not_null) {
		if ($not_null === true) {
			if ($this->_is_null($value) == true) {
				ACWError::add($key, sprintf(self::ERR_HISSU, $name));
				return -1;
			}
		} else if ($this->_is_null($value) == true) {
			// NULL可の時にNULLなので処理を継続しない
			return 1;
		}
		return 0;	// 処理継続
	}
}
/* ファイルの終わり */