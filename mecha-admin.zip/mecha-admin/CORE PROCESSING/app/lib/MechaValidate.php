<?php
/**
 * エラーチェックライブラリ
 */
class MechaValidate_lib
{
	const ERR_KEYS_HISSU                   = 'ERR_HISSU';
	const ERR_KEYS_ZENKANA                 = 'ERR_ZENKANA';
	const ERR_KEYS_ZENKANASPACE            = 'ERR_ZENKANASPACE';
	const ERR_KEYS_HANKAKUSUUJI            = 'ERR_HANKAKUSUUJI';
	const ERR_KEYS_BIGSUUJI                = 'ERR_BIGSUUJI';
	const ERR_KEYS_HANISUUJI               = 'ERR_HANISUUJI';
	const ERR_KEYS_IJOUSUUJI               = 'ERR_IJOUSUUJI';
	const ERR_KEYS_IKASUUJI                = 'ERR_IKASUUJI';
	const ERR_KEYS_YMD                     = 'ERR_YMD';
	const ERR_KEYS_YM                      = 'ERR_YM';
	const ERR_KEYS_FUSEI                   = 'ERR_FUSEI';
	const ERR_KEYS_DATE1900                = 'ERR_DATE1900';
	const ERR_KEYS_HANKAKUEISUU            = 'ERR_HANKAKUEISUU';
	const ERR_KEYS_SEISUU                  = 'ERR_SEISUU';
	const ERR_KEYS_SYOUSUU                 = 'ERR_SYOUSUU';
	const ERR_KEYS_MOJIIKA                 = 'ERR_MOJIIKA';
	const ERR_KEYS_MOJIIJOU                = 'ERR_MOJIIJOU';
	const ERR_KEYS_MOMJISUU                = 'ERR_MOMJISUU';
	const ERR_KEYS_MOJIIJOUMOJIIKA         = 'ERR_MOJIIJOUMOJIIKA';
	const ERR_KEYS_MOJIIKA_ZENKAKU         = 'ERR_MOJIIKA_ZENKAKU';
	const ERR_KEYS_MOJIIJOU_ZENKAKU        = 'ERR_MOJIIJOU_ZENKAKU';
	const ERR_KEYS_MOMJISUU_ZENKAKU        = 'ERR_MOMJISUU_ZENKAKU';
	const ERR_KEYS_MOJIIJOUMOJIIKA_ZENKAKU = 'ERR_MOJIIJOUMOJIIKA_ZENKAKU';
	const ERR_KEYS_ALLZEN                  = 'ERR_ALLZEN';
	const ERR_KEYS_ALLHAN                  = 'ERR_ALLHAN';
	const ERR_KEYS_BUNSU                   = 'ERR_BUNSU';

	static private $MSG;
	static private $KEYS = array(
		self::ERR_KEYS_HISSU                   => 'M0001',
		self::ERR_KEYS_ZENKANA                 => 'M0002',
		self::ERR_KEYS_ZENKANASPACE            => 'M0003',
		self::ERR_KEYS_HANKAKUSUUJI            => 'M0004',
		self::ERR_KEYS_BIGSUUJI                => 'M0005',
		self::ERR_KEYS_HANISUUJI               => 'M0006',
		self::ERR_KEYS_IJOUSUUJI               => 'M0007',
		self::ERR_KEYS_IKASUUJI                => 'M0008',
		self::ERR_KEYS_YMD                     => 'M0009',
		self::ERR_KEYS_YM                      => 'M0010',
		self::ERR_KEYS_FUSEI                   => 'M0011',
		self::ERR_KEYS_DATE1900                => 'M0012',
		self::ERR_KEYS_HANKAKUEISUU            => 'M0013',
		self::ERR_KEYS_SEISUU                  => 'M0014',
		self::ERR_KEYS_SYOUSUU                 => 'M0015',
		self::ERR_KEYS_MOJIIKA                 => 'M0016',
		self::ERR_KEYS_MOJIIJOU                => 'M0017',
		self::ERR_KEYS_MOMJISUU                => 'M0018',
		self::ERR_KEYS_MOJIIJOUMOJIIKA         => 'M0019',
		self::ERR_KEYS_MOJIIKA_ZENKAKU         => 'M0020',
		self::ERR_KEYS_MOJIIJOU_ZENKAKU        => 'M0021',
		self::ERR_KEYS_MOMJISUU_ZENKAKU        => 'M0022',
		self::ERR_KEYS_MOJIIJOUMOJIIKA_ZENKAKU => 'M0023',
		self::ERR_KEYS_ALLZEN                  => 'M0024',
		self::ERR_KEYS_ALLHAN                  => 'M0025',
		self::ERR_KEYS_BUNSU                   => 'M0026',
	);

	/**
	 * コンストラクタ
	 */
	public function __construct($message)
	{
		self::$MSG = array();
		foreach ($message as $key => $msg) {
			$err_key = array_search($key, self::$KEYS);
			if ($err_key !== false) {
				self::$MSG[$err_key] = $msg;
			}
		}
	}

	/**
	 * 全角チェック（UTF-8仕様）
	 */
	public function type_zenkaku($key, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		// 全角チェック
		$v = str_replace(array("\r", "\n"), '', $value); // 改行を取り除く
		if (! preg_match('/^[^ -~｡-ﾟ\x00-\x1f\t]+$/u', $v)) {
			ACWError::add($key, self::$MSG[self::ERR_KEYS_ALLZEN]);
			return false;
		}

		// 長さチェック
		return $this->_check_length($key, $value, $max, $min);
	}

	/**
	 * 半角チェック（UTF-8仕様）
	 */
	public function type_hankaku($key, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		// 半角チェック
		if (! preg_match('/^[｡-ﾟｰ !-~]+$/u', $value)) {
			ACWError::add($key, self::$MSG[self::ERR_KEYS_ALLHAN]);
			return false;
		}

		// 長さチェック
		return $this->_check_length($key, $value, $max, $min);
	}

	/**
	 * 分数チェック
	 */
	public function type_bunsu($key, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		// 分数チェック
		if (! preg_match('/^[0-9]+(\/[0-9]+)?$/', $value)) {
			ACWError::add($key, self::$MSG[self::ERR_KEYS_BUNSU]);
			return false;
		}

		// 長さチェック
		return $this->_check_length($key, $value, $max, $min);
	}

	/**
	 * 文字列チェック
	 */
	public function type_str($key, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		// 長さチェック
		return $this->_check_length($key, $value, $max, $min);
	}

	/**
	 * バイト数チェック
	 */
	public function type_byte($key, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		// 長さチェック
		return $this->_check_length_byte($key, $value, $max, $min);
	}

	/**
	 * 全角カナ文字列チェック
	 */
	public function zen_kana($key, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		// 長さチェック
		if ($this->_check_length($key, $value, $max, $min, true) == false) {
			return false;
		}

		// カナのみチェック
		if (! preg_match("/^[ァ-ヶー]+$/u", $value)) {  
			ACWError::add($key, self::$MSG[self::ERR_KEYS_ZENKANA]);
			return false;
		}
		return true;
	}

	/**
	 * 全角カナ文字列スペースありチェック
	 */
	public function zen_kana_space($key, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		// 長さチェック
		if ($this->_check_length($key, $value, $max, $min, true) == false) {
			return false;
		}

		// カナチェック
		if (! preg_match("/^[ァ-ヶー　 ]+$/u", $value)) {  
			ACWError::add($key, self::$MSG[self::ERR_KEYS_ZENKANASPACE]);
			return false;
		}
		return true;
	}

	/**
	 * 数値チェック 最大値　最小値制限
	 */
	public function type_int($key, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		if (! preg_match('/^-?\d+$/', $value)) {
			ACWError::add($key, self::$MSG[self::ERR_KEYS_HANKAKUSUUJI]);
			return false;
		}

		if (settype($value, 'integer') == false) {
			ACWError::add($key, self::$MSG[self::ERR_KEYS_BIGSUUJI]);
			return false;
		}

		if (is_null($min) == false && is_null($max) == false) {
			if ($min > $value || $value > $max) {
				ACWError::add($key, sprintf(self::$MSG[self::ERR_KEYS_HANISUUJI], $min, $max));
				return false;
			}
		}

		if (is_null($min) == false) {
			if ($min > $value) {
				ACWError::add($key, sprintf(self::$MSG[self::ERR_KEYS_IJOUSUUJI], $min));
				return false;
			}
		}

		if (is_null($max) == false) {
			if ($value > $max) {
				ACWError::add($key, sprintf(self::$MSG[self::ERR_KEYS_IKASUUJI], $max));
				return false;
			}
		}

		return true;
	}

	/**
	 * 日付チェック YYYY/MM/DD
	 */
	public function type_ymd($key, $value, $not_null) {
		// NULLチェック
		switch ($this->_check_null($key, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		if (! preg_match('/^\d{4}\/\d{1,2}\/\d{1,2}$/', $value)) {
			ACWError::add($key, self::$MSG[self::ERR_KEYS_YMD]);
			return false;
		}

		$ary = explode('/', $value);
		if (checkdate($ary[1], $ary[2], $ary[0])) {
			if ((1900 <= $ary[0]) && ($ary[0] <= 2100)) {
				return true;
			}
		}

		ACWError::add($key, self::$MSG[self::ERR_KEYS_FUSEI]);
		return false;
	}

	/**
	 * 日付チェック YYYY/MM
	 */
	public function type_ym($key, $value, $not_null) {
		// NULLチェック
		switch ($this->_check_null($key, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		if (! preg_match('/^\d{4}\/\d{1,2}$/', $value)) {
			ACWError::add($key, self::$MSG[self::ERR_KEYS_YM]);
			return false;
		}

		$ary = explode('/', $value);
		if (checkdate($ary[1], 1, $ary[0])) {
			if ((1900 <= $ary[0]) && ($ary[0] <= 2100)) {
				return true;
			}
		}

		ACWError::add($key, self::$MSG[self::ERR_KEYS_FUSEI]);
		return false;
	}

	/**
	 * 数値または文字列
	 */
	public function alpha_number($key, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		if (! preg_match("/^[a-zA-Z0-9]+$/", $value)) {
			ACWError::add($key, self::$MSG[self::ERR_KEYS_HANKAKUEISUU]);
			return false;
		}

		// 長さチェック
		return $this->_check_length($key, $value, $max, $min, false);
	}

	/**
	 * 小数点あり数値
	 */
	public function type_float($key, $value, $not_null, $intNum = null, $decNum = null) {
		// NULLチェック
		switch ($this->_check_null($key, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		if (! preg_match("/^-?(\d+)(?:\.(\d+))?$/", $value, $match)) {
			ACWError::add($key, self::$MSG[self::ERR_KEYS_HANKAKUSUUJI]);
			return false;
		}

		if (! is_null($intNum)) {
			if ($intNum < strlen($match[1])) {
				ACWError::add($key, sprintf(self::$MSG[self::ERR_KEYS_SEISUU], $intNum));
				return false;
			}
		}
		if (! is_null($decNum)) {
			if ((isset($match[2]) === true) && ($decNum < strlen($match[2]))) {
				ACWError::add($key, sprintf(self::$MSG[self::ERR_KEYS_SYOUSUU], $decNum));
				return false;
			}
		}

		return true;
	}

	/**
	 * 数字のみ　桁数チェック
	 */
	public function type_number($key, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		if (! preg_match("/^\d+$/", $value)) {
			ACWError::add($key, self::$MSG[self::ERR_KEYS_HANKAKUSUUJI]);
			return false;
		}

		// 長さチェック
		return $this->_check_length($key, $value, $max, $min, false);
	}

	/**
	 * 電話番号
	 */
	public function tel($key, $value, $not_null) {
		// NULLチェック
		switch ($this->_check_null($key, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		if (! preg_match("/^0\d{9,10}$/ ", $value)) {
			ACWError::add($key, self::$MSG[self::ERR_KEYS_FUSEI]);
			return false;
		}

		return true;
	}

	/**
	 * 郵便番号
	 */
	public function post_code($key, $value, $not_null) {
		// NULLチェック
		switch ($this->_check_null($key, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		if (! preg_match("/^\d{7}$/", $value)) {
			ACWError::add($key, self::$MSG[self::ERR_KEYS_FUSEI]);
			return false;
		}

		return true;
	}

	/**
	 * メール
	 */
	public function mail($key, $value, $not_null, $max = null, $min = null) {
		// NULLチェック
		switch ($this->_check_null($key, $value, $not_null)) {
			case -1:
				return false;	// NULLエラー
			case 1:
				return true;	// NULLなのでチェックしない
		}

		if (! preg_match("/^[a-zA-Z0-9]+[a-zA-Z0-9\._-]*@[a-zA-Z0-9_-]+\.[a-zA-Z0-9\._-]+$/", $value)) {
			ACWError::add($key, self::$MSG[self::ERR_KEYS_FUSEI]);
			return false;
		}

		// 長さチェック
		return $this->_check_length($key, $value, $max, $min, false);
	}

	// 長さをチェック
	public function _check_length($key, $value, $max, $min)
	{
		$error_flag = false;
		$vlen = mb_strlen($value);

		if (! is_null($min) && $min > $vlen) {
			$error_flag = true;
		}
		if (! is_null($max) && $max < $vlen) {
			$error_flag = true;
		}

		if ($error_flag == true) {
			if (is_null($min)) {
				ACWError::add($key, sprintf(self::$MSG[self::ERR_KEYS_MOJIIKA], $max));
			} else if (is_null($max)) {
				ACWError::add($key, sprintf(self::$MSG[self::ERR_KEYS_MOJIIJOU], $min));
			} else if ($max == $min) {
				ACWError::add($key, sprintf(self::$MSG[self::ERR_KEYS_MOMJISUU], $max));
			} else {
				ACWError::add($key, sprintf(self::$MSG[self::ERR_KEYS_MOJIIJOUMOJIIKA], $min, $max));
			}
			return false;
		}

		return true;
	}

	// 長さをチェック(バイト数)
	public function _check_length_byte($key, $value, $max, $min)
	{
		$error_flag = false;
		$len = strlen(Enc_lib::u2s($value));

		if (! is_null($min) && $min > $len) {
			$error_flag = true;
		}
		if (! is_null($max) && $max < $len) {
			$error_flag = true;
		}

		if ($error_flag == true) {
			$half_max = floor( $max / 2 );
			$half_min = floor( $min / 2 );

			if (is_null($min)) {
				ACWError::add($key, sprintf(self::$MSG[self::ERR_KEYS_MOJIIKA_ZENKAKU], $max, $half_max));
			} else if (is_null($max)) {
				ACWError::add($key, sprintf(self::$MSG[self::ERR_KEYS_MOJIIJOU_ZENKAKU], $min, $half_min));
			} else if ($max == $min) {
				ACWError::add($key, sprintf(self::$MSG[self::ERR_KEYS_MOMJISUU_ZENKAKU], $max, $half_max));
			} else {
				ACWError::add($key, sprintf(self::$MSG[self::ERR_KEYS_MOJIIJOUMOJIIKA_ZENKAKU], $min, $max, $half_min, $half_max));
			}
			return false;
		}

		return true;
	}

	/////////////////////////////////////////////////////////////////////////
	// 内部関数
	/////////////////////////////////////////////////////////////////////////

	// NULLかどうかの判定
	protected function _is_null($value) {
		if (is_null($value)) {
			return true;
		}
		if (! is_string($value)) {
			settype($value, "string");
		}
		if ($value == '') {
			return true;
		}
		return false;
	}

	protected function _check_null($key, $value, $not_null) {
		if ($not_null === true) {
			if ($this->_is_null($value) == true) {
				ACWError::add($key, self::$MSG[self::ERR_KEYS_HISSU]);
				return -1;
			}
		} else if ($this->_is_null($value) == true) {
			// NULL可の時にNULLなので処理を継続しない
			return 1;
		}
		return 0;	// 処理継続
	}
}
/* ファイルの終わり */