<?php

/**
 * 画像操作ライブラリ
 * ImageMagicをインストールしないとエラーとなる
 * Ghostscript 9.10がないとエラーとなる
 */
class Image2_lib
{

	public function create_thumbnail2($from_file, $to_file)
	{
		try {
			// 出力ファイルの拡張子に従う
			$pinfo = Path_lib::info($to_file);
			$ext = $pinfo['extension'];
			
			$im = new Imagick();
			$im->readimage($from_file);
			
			$im->setResourceLimit(6, 1); // 1スレッドに制限
			$im->setIteratorIndex(0); // 画像リストの1番目
			$im->setImageFormat($ext); // 変換
			$im->setBackgroundColor('white'); // 背景色
			// CMYK→RGB 色変更
			$this->_cmyk_to_rgb($im);
			
			$im->writeImage($to_file); // ファイルへ
			$im->destroy(); // 破棄
		} catch (Exception $e) {
			ACWLog::write_file('IMAGEERROR', $e->getMessage());
			return false;
		}
		return true;
	}
	
	public function resize($to_file, $width, $height)
	{
		try {
			$im = new Imagick();
			$im->readimage($to_file);

			$im->setResourceLimit(6, 1); // 1スレッドに制限
			$im->setIteratorIndex(0); // 画像リストの1番目
			
			// 解像度とサイズ
			$im->setImageResolution(72, 72);
			$im->thumbnailImage($width, $height, true);
			
			$im->writeImage($to_file);
			$im->destroy(); // 破棄
		} catch (Exception $e) {
			ACWLog::write_file('IMAGEERROR', $e->getMessage());
			return false;
		}
		return true;
	}

	
	private function _cmyk_to_rgb($img)
	{
		// don't use this (it inverts the image)
		//    $img->setImageColorspace (imagick::COLORSPACE_RGB);

		if ($img->getImageColorspace() != Imagick::COLORSPACE_CMYK) {
			return;
		}
		$profiles = $img->getImageProfiles('*', false);
		// we're only interested if ICC profile(s) exist
		$has_icc_profile = (array_search('icc', $profiles) !== false);
		// if it doesnt have a CMYK ICC profile, we add one
		if ($has_icc_profile === false) {
			$icc_cmyk = file_get_contents(ACW_VENDOR_DIR . '/color_profile/JapanWebCoated.icc');
			$img->profileImage('icc', $icc_cmyk);
			unset($icc_cmyk);
		}
		// then we add an RGB profile
		$icc_rgb = file_get_contents(ACW_VENDOR_DIR . '/color_profile/sRGB_v4_ICC_preference.icc');
		$img->profileImage('icc', $icc_rgb);
		unset($icc_rgb);

		$img->stripImage(); // this will drop down the size of the image dramatically (removes all profiles)
	}
}

/* ファイルの終わり */