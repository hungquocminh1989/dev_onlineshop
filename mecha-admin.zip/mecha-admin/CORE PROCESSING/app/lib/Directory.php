<?php

/**
 * ディレクトリ操作ライブラリ
 */
class Directory_lib
{
	/**
	 * 安全な削除
	 */
	public static function safe_remove($target, $and_self_remove = false)
	{
		$target = rtrim($target, '/');
		if (file_exists($target) === false) {
			return;
		}
		if (is_dir($target) === false) {
			return unlink($target); // ディレクトリではない
		}
		self::_remove_dir($target);
		if ($and_self_remove === true) {
			rmdir($target);
		}
	}

	private static function _remove_dir($target)
	{
		$list = self::get_file_list($target);
		foreach ($list as $filename) {
			$path = $target . '/' . $filename;
			if (is_dir($path)) {
				// 再帰
				self::_remove_dir($path);
				rmdir($path);
			} else {
				unlink($path);
			}
		}
	}

	/**
	 * 安全なコピー
	 */
	public static function safe_copy($source_dir, $target_dir)
	{
		if (file_exists($source_dir) === false) {
			throw new Exception('[safe_copy]コピー元が存在しません。' . $source_dir);
		}
		if (file_exists($target_dir) === false) {
			mkdir($target_dir);
		}
		self::_copy($source_dir, $target_dir);
	}

	private static function _copy($source_dir, $target_dir)
	{
		$list = self::get_file_list($source_dir);
		foreach ($list as $filename) {
			$old_name = $source_dir . '/' . $filename;
			$new_name = $target_dir . '/' . $filename;
			if (is_dir($old_name)) {
				// ディレクトリ
				if (file_exists($new_name) == false) {
					// ないので作る
					mkdir($new_name);
				}
				self::_copy($old_name, $new_name);
			} else {
				if (file_exists($new_name)) {
					// あるので消す
					unlink($new_name);
				}
				copy($old_name, $new_name);
			}
		}
	}

	/**
	 * ファイル名一覧
	 */
	public static function get_file_list($source_dir)
	{
		$file_list = array();
		$handle = opendir($source_dir);
		if ($handle) {
			while ($filename = readdir($handle)) {
				if (strcmp($filename, '.') != 0 && strcmp($filename, '..') != 0) {
					$file_list[] = $filename;
				}
			}
			closedir($handle);
		}
		return $file_list;
	}
}
/* ファイルの終わり */