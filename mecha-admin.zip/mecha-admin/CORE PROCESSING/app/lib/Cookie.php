<?php
/**
 * COOKIE操作ライブラリ
 */
class Cookie_lib
{
	/**
	 * 保存する日数
	 */
	const KEEP_DAYS = 30;

	/**
	 * クッキーをセットする
	 *
	 * @param	string	キー
	 * @param	mixed	値
	 * @param	string	有効としたいパス
	 * @return	boolean	成功時:true、失敗時:false
	 */
	public static function set($name, $value, $keep_path = '/')
	{
		return setcookie($name, $value, time() + (60 * 60 * 24 * self::KEEP_DAYS), $keep_path);
	}

	/**
	 * クッキーを返す
	 *
	 * @param	string	キー
	 * @param	mixed	取得できない場合に返す値
	 * @return	mixed	値
	 */
	public static function get($name, $default = null)
	{
		if (isset($_COOKIE[$name])) {
			return $_COOKIE[$name];
		}
		return $default;
	}

	/**
	 * クッキーを削除する
	 *
	 * @param	string	キー
	 * @param	string	有効としたいパス
	 * @return	boolean	成功時:true、失敗時:false
	 */
	public static function delete($name, $keep_path = '/')
	{
		unset($_COOKIE[$name]);
		return setcookie($name, null, -86400, $keep_path);
	}
}
