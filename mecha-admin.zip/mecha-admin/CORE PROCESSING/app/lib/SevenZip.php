<?php
/**
 * 7zip操作ライブラリ（app\lib\exe\7za.exe があることが前提）
 */
class SevenZip_lib
{
	/* 例
		SevenZip_lib::compress('C:\web\htdocs\biken.dev\tmp\download\hb_script', 'C:\web\htdocs\biken.dev\tmp\download\hb_script２.zip');
		SevenZip_lib::extract('C:\web\htdocs\biken.dev\tmp\download', 'C:\web\htdocs\biken.dev\tmp\download\test\hb_script.zip');
	*/
	
	/**
	 * 圧縮
	 *
	 * @param	string	圧縮するフォルダのパス
	 * @param	string	圧縮したファイルを保存するフォルダのパス
	 * @return	number	成功時:0
	 */
	public static function compress($dir, $zip_path)
	{
		$comm = sprintf(ACW_APP_DIR . '/lib/exe/7za.exe a "%s" "%s"', $zip_path, $dir);
		$comm_sjis = mb_convert_encoding($comm, 'sjis-win', 'UTF-8');
		$result_exec = exec($comm_sjis, $output, $return_var);
		
		self::_write_7zip_log('圧縮', $result_exec, $output, $return_var);
		
		return $return_var;
	}
	
	/**
	 * 解凍（抽出）
	 *
	 * @param	string	解凍したフォルダを置くフォルダのパス
	 * @param	string	圧縮ファイルのパス
	 * @return	number	成功時:0
	 */
	public static function extract($dir, $zip_path)
	{
		$comm = sprintf(ACW_APP_DIR . '/lib/exe/7za.exe x "%s" -o"%s"', $zip_path, $dir);
		$comm_sjis = mb_convert_encoding($comm, 'sjis-win', 'UTF-8');
		$result_exec = exec($comm_sjis, $output, $return_var);
		
		self::_write_7zip_log('解凍', $result_exec, $output, $return_var);
		
		return $return_var;
	}
	
	/**
	 * 7zip処理ログ
	 */
	private static function _write_7zip_log($kbn, $result_exec, $output, $return_var)
	{
		$log_str = "==========処理ログ==========
kbn        : %s
result     : %s
return_var : %s
output     : %s
";
		
		ACWLog::debug_var('7zip', sprintf($log_str, $kbn, $result_exec, $return_var, var_export($output, true)));
	}
}
