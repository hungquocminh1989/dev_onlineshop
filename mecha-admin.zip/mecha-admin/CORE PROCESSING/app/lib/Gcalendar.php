<?php
/**
 * Googleカレンダーライブラリ
 */
class Gcalendar_lib
{
	/**
	 * GoogleAPIキー（argo.inc.jp@gmail.com）
	 */
	const MY_API_KEY = 'AIzaSyDWuioYBOvfZ6oND2HKVWVeruuIacYKxkc';

	/**
	 * エラーメッセージ
	 */
	private static $_str_error = null;

	/**
	 * エラーメッセージを返す
	 * @return	string	エラーメッセージ
	 */
	public static function get_error_string()
	{
		return self::$_str_error;
	}

	/**
	 * 祝日を配列形式で返す
	 * @param	string	取得対象年
	 * @param	string	年月日フォーマット
	 * @return	array	取得対象年の祝日
	 */
	public static function get_holiday_array($year, $fmt = 'Y-m-d')
	{
		self::$_str_error = null;
		$holidays = array();

		// 祝日のJSONファイルを取得
		list($contents, $resheader, $url) = self::_get_holiday_jsonfile($year);

		// JSON形式を配列に変更
		$data = json_decode($contents);

		// 読込結果：正常
		if (isset($resheader[0]) && (strpos($resheader[0], '200') !== false)) {
			foreach ($data->items as $item) {
				$dt = new DateTime((string)$item->start->date);
				$titles = explode('/', (string)$item->summary);
				$holidays[$dt->format($fmt)] = trim($titles[0]); // key:年月日、value:祝日名
			}
			if (! empty($holidays)) {
				ksort($holidays); // 祝日の昇順
			} else {
				self::$_str_error = $year . '年の祝日はゼロ件です。';
			}

		// 読込結果：異常
		} else {
			if (isset($data->error)) {
				self::$_str_error = 'URLの設定に誤りがあります。';
			} else {
				self::$_str_error = 'HTTPエラーが発生しました。';
			}
			self::$_str_error .= PHP_EOL . 'URL：' . $url;
		}

		return $holidays;
	}

	/**
	 * 祝日のJSONファイルを返す
	 * @param	string	取得対象年
	 * @return	array	0:祝日JSONファイル、1:HTTPレスポンス結果、2:実行したURL
	 */
	private static function _get_holiday_jsonfile($year)
	{
		// HTTPレスポンス結果をリセット（PHP定義済の変数）
		$http_response_header = null;

		$url = sprintf(
			'https://www.googleapis.com/calendar/v3/calendars/%s/events?key=%s&timeMin=%s&timeMax=%s&maxResults=%d&orderBy=startTime&singleEvents=true'
//		,	'outid3el0qkcrsuf89fltf7a4qbacgt9@import.calendar.google.com' // mozilla.org版
		,	'japanese__ja@holiday.calendar.google.com' // google版
		,	self::MY_API_KEY
		,	$year . '-01-01T00:00:00Z' // 取得開始日
		,	$year . '-12-31T00:00:00Z' // 取得終了日
		,	99 // 最大取得数（1年間なら30もあれば十分）
		);

		// ファイル読込
		$contents = file_get_contents(
			$url
		,	false
		,	stream_context_create(array('http' => array('ignore_errors' => true)))
		);

		return array($contents, $http_response_header, $url);
	}
}
/* ファイルの終わり */