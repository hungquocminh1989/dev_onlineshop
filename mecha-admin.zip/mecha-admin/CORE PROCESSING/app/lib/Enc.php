<?php
/**
 * エンコード操作ライブラリ
 */
class Enc_lib
{
	/**
	 * 変換：utf-8 → sjis-win
	 *
	 * @param	string	変換前文字列
	 * @return	string	変換後文字列
	 */
	public static function u2s($str)
	{
		return mb_convert_encoding($str, 'sjis-win', 'utf-8');
	}

	/**
	 * 変換：sjis-win → utf-8
	 *
	 * @param	string	変換前文字列
	 * @return	string	変換後文字列
	 */
	public static function s2u($str)
	{
		return mb_convert_encoding($str, 'utf-8', 'sjis-win');
	}

	/**
	 * 変換：windowsサーバー用
	 *
	 * @param	string	変換前文字列
	 * @return	string	変換後文字列
	 */
	public static function win($str)
	{
		if (ACW_WINDOWS) {
			$internal_enc = mb_internal_encoding();
			if (stripos($internal_enc, 'sjis') === false) {
				return mb_convert_encoding($str, 'sjis-win', $internal_enc);
			}
		}
		return $str;
	}
}
