<?php
/*
	SA･･･DE
	***************************************************************************		
		X軸最高速度

				表示		 : T0193(T0214)	

				バインド変数 : T0034	形式1
							　 T0071	形式2
							   T0035	大きさ
							   T0062	軸構成
							   T0073	分解能

	***************************************************************************
		S軸最高速度

				表示		 : T0194	

				バインド変数 : T0034	形式1
							　 T0071	形式2
							   T0035	大きさ
							   T0062	軸構成
							   T0073	分解能

	***************************************************************************
		X軸最大搭載質量

				表示		 : T0191	
							
				バインド変数 : T0034	形式1
							   T0071	形式2
							   T0035	大きさ
							   T0062	軸構成
	
	***************************************************************************	
		S軸最大搭載質量

				表示		 : T0192	

				バインド変数 : T0034	形式1
							   T0071	形式2
							   T0035	大きさ
							   T0062	軸構成
		
	***************************************************************************		

		最大ストローク

				表示		 : T0026	

				バインド変数 : T0034	形式1
							   T0071	形式2
							   T0035	大きさ
							   T0062	軸構成
							   	
	***************************************************************************	

		精度

				表示		 : T0195	X軸繰返し位置決め精度
							   T0196	X軸繰返し位置決め精度


				バインド変数 : T0034	形式1
				               T0071	形式2
							   T0035	大きさ
							   T0062	軸構成
							   T0073	分解能

	***************************************************************************	

		最大（定格）推力

				表示		 : T0218	最大推力
							   T0219	定格推力
							   T0224	最大トルク
							   T0225	定格トルク

				バインド変数 : T0034	形式1
				               T0071	形式2
							   T0035	大きさ
							   T0062	軸構成

	***************************************************************************	

		有効動作角度

				表示		 : T0226	

				バインド変数 : T0034	形式1
				               T0071	形式2
							   T0035	大きさ
							   T0062	軸構成

	***************************************************************************	

		製品質量

				表示		 : T0250	

				バインド変数 : T0034	形式1
				               T0071	形式2
							   T0035	大きさ
							   T0062	軸構成

	***************************************************************************	

*/

class SeinoSA2DE_find extends ACWDB
{
	public static function get($param)
	{
		$db = new self;
		
		$sql_p = array(
			't00340' => $param['t0034'],
			't00710' => $param['t0071'],
			't00350' => $param['t0035'],
			't00620' => $param['t0062'],
			't00730' => $param['t0073'],
			't00341' => $param['t0034'],
			't00711' => $param['t0071'],
			't00351' => $param['t0035'],
			't00621' => $param['t0062'],
			't00731' => $param['t0073'],
			't00342' => $param['t0034'],
			't00712' => $param['t0071'],
			't00352' => $param['t0035'],
			't00622' => $param['t0062'],
			't00343' => $param['t0034'],
			't00713' => $param['t0071'],
			't00353' => $param['t0035'],
			't00623' => $param['t0062'],
			't00344' => $param['t0034'],
			't00714' => $param['t0071'],
			't00354' => $param['t0035'],
			't00624' => $param['t0062'],
			't00345' => $param['t0034'],
			't00715' => $param['t0071'],
			't00355' => $param['t0035'],
			't00625' => $param['t0062'],
			't00735' => $param['t0073'],
			't00346' => $param['t0034'],
			't00716' => $param['t0071'],
			't00356' => $param['t0035'],
			't00626' => $param['t0062'],
			't00736' => $param['t0073'],
			't00347' => $param['t0034'],
			't00717' => $param['t0071'],
			't00357' => $param['t0035'],
			't00627' => $param['t0062'],
			't00348' => $param['t0034'],
			't00718' => $param['t0071'],
			't00358' => $param['t0035'],
			't00628' => $param['t0062'],
			't00349' => $param['t0034'],
			't00719' => $param['t0071'],
			't00359' => $param['t0035'],
			't00629' => $param['t0062'],
			't003410' => $param['t0034'],
			't007110' => $param['t0071'],
			't003510' => $param['t0035'],
			't006210' => $param['t0062'],
			't003411' => $param['t0034'],
			't007111' => $param['t0071'],
			't003511' => $param['t0035'],
			't006211' => $param['t0062'],
			't003412' => $param['t0034'],
			't007112' => $param['t0071'],
			't003512' => $param['t0035'],
			't006212' => $param['t0062']
		);
		
		$sql = "
	SELECT 			
	
			'T0214'			AS ITEM_ID
			,T0193			AS DATA
	FROM M_MAX_SPEED
	WHERE	T0034		= :t00340
		AND T0071		= :t00710
		AND T0035 		= :t00350
		AND T0062		= :t00620
		AND T0073		= :t00730
		AND DELETE_FLG  = 'FALSE'
	UNION 
	SELECT 			
	
			'T0194'			AS ITEM_ID
			,T0194			AS DATA
	FROM M_MAX_SPEED
	WHERE	T0034		= :t00341
		AND T0071		= :t00711
		AND T0035 		= :t00351
		AND T0062		= :t00621
		AND T0073		= :t00731
		AND DELETE_FLG  = 'FALSE'
	UNION 
	SELECT 

			'T0213'			
			,T0191			
	FROM M_MAX_TOSAI_SHITSURYO
	WHERE	T0034		= :t00342
		AND T0071		= :t00712
		AND T0035 		= :t00352
		AND T0062		= :t00622
		AND DELETE_FLG  = 'FALSE'
	UNION 
	SELECT 
			'T0192'		
			,T0192			
	FROM M_MAX_TOSAI_SHITSURYO
	WHERE	T0034		= :t00343
		AND T0071		= :t00713
		AND T0035 		= :t00353
		AND T0062		= :t00623
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
			'T0217'		
			,T0026		
	FROM M_MAX_STROKE
	WHERE   T0034		= :t00344
		AND T0071		= :t00714
		AND T0035 		= :t00354
		AND T0062		= :t00624
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
		 'T0195'
		 ,T0195
	FROM M_QUALITY
	WHERE	T0034		= :t00345
		AND T0071		= :t00715
		AND T0035 		= :t00355
		AND T0062		= :t00625
		AND T0073		= :t00735
		AND DELETE_FLG  = 'FALSE'	
	UNION
	SELECT 
		 'T0196'
		 ,T0196
	FROM M_QUALITY
	WHERE	T0034		= :t00346
		AND T0071		= :t00716
		AND T0035 		= :t00356
		AND T0062		= :t00626
		AND T0073		= :t00736
		AND DELETE_FLG  = 'FALSE'	
	UNION
	SELECT 			
			'T0218'			AS ITEM_ID
			,T0218			AS DATA
	FROM M_MAX_THRUST
	WHERE	T0034		= :t00347
		AND T0071		= :t00717
		AND T0035 		= :t00357
		AND T0062		= :t00627
		AND DELETE_FLG  = 'FALSE'
	UNION 
	SELECT 			
			'T0219'			AS ITEM_ID
			,T0219			AS DATA
	FROM M_MAX_THRUST
	WHERE	T0034		= :t00348
		AND T0071		= :t00718
		AND T0035 		= :t00358
		AND T0062		= :t00628
		AND DELETE_FLG  = 'FALSE'
	UNION 
	SELECT 			
			'T0224'			AS ITEM_ID
			,T0224			AS DATA
	FROM M_MAX_THRUST
	WHERE	T0034		= :t00349
		AND T0071		= :t00719
		AND T0035 		= :t00359
		AND T0062		= :t00629
		AND DELETE_FLG  = 'FALSE'
	UNION 
	SELECT 			
			'T0225'			AS ITEM_ID
			,T0225			AS DATA
	FROM M_MAX_THRUST
	WHERE	T0034		= :t003410
		AND T0071		= :t007110
		AND T0035 		= :t003510
		AND T0062		= :t006210
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
			'T0226'		
			,T0226		
	FROM M_MAX_STROKE
	WHERE   T0034		= :t003411
		AND T0071		= :t007111
		AND T0035 		= :t003511
		AND T0062		= :t006211
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
			'T0250'		
			,T0250		
	FROM M_SEIHIN_SHITSURYO
	WHERE   T0034		= :t003412
		AND T0071		= :t007112
		AND T0035 		= :t003512
		AND T0062		= :t006212
		AND DELETE_FLG  = 'FALSE'
		";
		
		return $db->query($sql, $sql_p);
	}
}
