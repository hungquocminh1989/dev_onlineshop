<?php
/*
	CTX･･･M
	***************************************************************************		
		最高速度

				表示		 : T0027	

				バインド変数 : T0034	形式1
							   T0071	形式2
							   T0035	大きさ
	
	***************************************************************************
		最大搭載質量

				表示		 : T0028	

				バインド変数 : T0034	形式1
							   T0071	形式2
							   T0035	大きさ

	***************************************************************************		

		X軸最大ストローク

				表示		 : T0175	

				バインド変数 : T0034	形式1
							   T0071	形式2
							   T0035	大きさ
							   T0048	X軸ストローク長さ
							   T0049	Y軸ストローク長さ							   

	***************************************************************************		

		Y軸最大ストローク

				表示		 : T0176	
					
				バインド変数 : T0034	形式1
							   T0071	形式2
							   T0035	大きさ
							   T0048	X軸ストローク長さ
							   T0049	Y軸ストローク長さ							   
		
	***************************************************************************	

		精度

				表示		 : T0157	繰返し位置決め精度
							   T0158	位置決め精度
							   T0159	ロストモーション
							   T0160	テーブル運動の平行度　A
							   T0162	姿勢精度
							   T0163	真直度


				バインド変数 : T0034	形式1
							   T0071	形式2
							   T0035	大きさ
							   T0048	X軸ストローク長さ
							   T0049	Y軸ストローク長さ							   
							   T0058	リニアエンコーダ						   
		
	***************************************************************************	

		製品質量

				表示		 : T0250	

				バインド変数 : T0034	形式1
							   T0071	形式2
							   T0035	大きさ
							   T0048	X軸ストローク長さ
							   T0049	Y軸ストローク長さ							   

	***************************************************************************	
*/

class SeinoCTX2M_find extends ACWDB
{
	public static function get($param)
	{
		$db = new self;
		
		$sql_p = array(
			't00340' => $param['t0034'],
			't00710' => $param['t0071'],
			't00350' => $param['t0035'],
			't00341' => $param['t0034'],
			't00711' => $param['t0071'],
			't00351' => $param['t0035'],
			't00342' => $param['t0034'],
			't00712' => $param['t0071'],
			't00352' => $param['t0035'],
			't00482' => $param['t0048'],
			't00492' => $param['t0049'],
			't00343' => $param['t0034'],
			't00713' => $param['t0071'],
			't00353' => $param['t0035'],
			't00483' => $param['t0048'],
			't00493' => $param['t0049'],
			't00344' => $param['t0034'],
			't00714' => $param['t0071'],
			't00354' => $param['t0035'],
			't00484' => $param['t0048'],
			't00494' => $param['t0049'],
			't00584' => $param['t0058'],
			't00345' => $param['t0034'],
			't00715' => $param['t0071'],
			't00355' => $param['t0035'],
			't00485' => $param['t0048'],
			't00495' => $param['t0049'],
			't00585' => $param['t0058'],
			't00346' => $param['t0034'],
			't00716' => $param['t0071'],
			't00356' => $param['t0035'],
			't00486' => $param['t0048'],
			't00496' => $param['t0049'],
			't00586' => $param['t0058'],
			't00347' => $param['t0034'],
			't00717' => $param['t0071'],
			't00357' => $param['t0035'],
			't00487' => $param['t0048'],
			't00497' => $param['t0049'],
			't00587' => $param['t0058'],
			't00348' => $param['t0034'],
			't00718' => $param['t0071'],
			't00358' => $param['t0035'],
			't00488' => $param['t0048'],
			't00498' => $param['t0049'],
			't00588' => $param['t0058'],
			't00349' => $param['t0034'],
			't00719' => $param['t0071'],
			't00359' => $param['t0035'],
			't00489' => $param['t0048'],
			't00499' => $param['t0049'],
			't00589' => $param['t0058'],
			't003410' => $param['t0034'],
			't007110' => $param['t0071'],
			't003510' => $param['t0035'],
			't004810' => $param['t0048'],
			't004910' => $param['t0049']
		);
		
		$sql = "
	SELECT 			

			'T0027'			AS ITEM_ID
			,T0027			AS DATA
	FROM M_MAX_SPEED
	WHERE	T0034		= :t00340
		AND T0071		= :t00710
		AND T0035 		= :t00350
		AND DELETE_FLG  = 'FALSE'
	UNION 
	SELECT 
			'T0028'			
			,T0028			
	FROM M_MAX_TOSAI_SHITSURYO
	WHERE	T0034		= :t00341
		AND T0071		= :t00711
		AND T0035 		= :t00351
		AND DELETE_FLG  = 'FALSE'
	UNION 
	SELECT 
			'T0175'		
			,T0175		
	FROM M_MAX_STROKE
	WHERE   T0034		= :t00342
		AND T0071		= :t00712
		AND T0035 		= :t00352
		AND T0048		= :t00482
		AND T0049		= :t00492
		AND DELETE_FLG  = 'FALSE'
	UNION 
	SELECT 
			'T0176'		
			,T0176		
	FROM M_MAX_STROKE
	WHERE   T0034		= :t00343
		AND T0071		= :t00713
		AND T0035 		= :t00353
		AND T0048		= :t00483
		AND T0049		= :t00493
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
		 'T0157'
		 ,T0157
	FROM M_QUALITY
	WHERE	T0034		= :t00344
		AND T0071		= :t00714
		AND T0035 		= :t00354
		AND T0048		= :t00484
		AND T0049		= :t00494
		AND T0058		= :t00584
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
		 'T0158'
		 ,T0158
	FROM M_QUALITY
	WHERE	T0034		= :t00345
		AND T0071		= :t00715
		AND T0035 		= :t00355
		AND T0048		= :t00485
		AND T0049		= :t00495
		AND T0058		= :t00585
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
		 'T0206'
		 ,T0159
	FROM M_QUALITY
	WHERE	T0034		= :t00346
		AND T0071		= :t00716
		AND T0035 		= :t00356
		AND T0048		= :t00486
		AND T0049		= :t00496
		AND T0058		= :t00586
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
		 'T0160'
		 ,T0160
	FROM M_QUALITY
	WHERE	T0034		= :t00347
		AND T0071		= :t00717
		AND T0035 		= :t00357
		AND T0048		= :t00487
		AND T0049		= :t00497
		AND T0058		= :t00587
		AND DELETE_FLG  = 'FALSE'
	UNION
		SELECT 
		 'T0207'
		 ,T0162
	FROM M_QUALITY
	WHERE	T0034		= :t00348
		AND T0071		= :t00718
		AND T0035 		= :t00358
		AND T0048		= :t00488
		AND T0049		= :t00498
		AND T0058		= :t00588
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
		 'T0163'
		 ,T0163
	FROM M_QUALITY
	WHERE	T0034		= :t00349
		AND T0071		= :t00719
		AND T0035 		= :t00359
		AND T0048		= :t00489
		AND T0049		= :t00499
		AND T0058		= :t00589
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
			'T0250'		
			,T0250		
	FROM M_SEIHIN_SHITSURYO
	WHERE   T0034		= :t003410
		AND T0071		= :t007110
		AND T0035 		= :t003510
		AND T0048		= :t004810
		AND T0049		= :t004910
		AND DELETE_FLG  = 'FALSE'
		";
		
		return $db->query($sql, $sql_p);
	}
}
