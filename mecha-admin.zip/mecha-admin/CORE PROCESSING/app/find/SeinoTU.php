<?php
/*
	TU
	***************************************************************************		
		最高速度

				表示		 : T0027	

				バインド変数 : T0034	形式1
							   T0035	大きさ
							   T0039	トラックの長さ
							   T0042	ボールねじのリード
							   T0054	ねじの種類
							   T0041	モータアタッチメント　
										（T0178	モータ形式種類 (AC or STP)を取得） 

	***************************************************************************
		最大搭載質量　水平

				表示		 : T0172	

				バインド変数 : T0034	形式1
							   T0035	大きさ
							   T0038	スライドテーブルの形状
							   T0042	ボールねじのリード
							   T0054	ねじの種類

	***************************************************************************	
		最大搭載質量　垂直

				表示		 : T0173	

				バインド変数 : T0034	形式1
							   T0035	大きさ
							   T0038	スライドテーブルの形状
							   T0042	ボールねじのリード
							   T0054	ねじの種類
		
	***************************************************************************		

		最大ストローク

				表示		 : T0026	

				バインド変数 : T0034	形式1
							   T0035	大きさ
							   T0038	スライドテーブルの形状
							　 T0039	トラックレール長さ	   
							   T0041	モータアタッチメント
										（T0179	モータの仕様 (ストレート or 折り返し)を取得）
                               T0042	ボールねじのリード
							   T0044	スライドテーブルの個数
							   T0045	カバー指定
							   T0056	Cルーブ
							   	
	***************************************************************************	

		精度

				表示		 : T0157	繰返し位置決め精度
							   T0158	位置決め精度
							   T0161	テーブル運動の平行度　B
							   T0164	バックラッシ


				バインド変数 : T0034	形式1
							   T0035	大きさ
							   T0038	スライドテーブルの形状
							   T0039	トラックレール長さ
							   T0041	モータアタッチメント
										（T0179	モータの仕様 (ストレート or 折り返し)を取得）
							　T0054	ねじの種類
							   		
	***************************************************************************	

		製品質量

				表示		 : T0250	

				バインド変数 : T0034	形式1
							   T0035	大きさ
							   T0038	スライドテーブルの形状
							　 T0039	トラックレール長さ	   
							   T0041	モータアタッチメント
										（T0179	モータの仕様 (ストレート or 折り返し)を取得）
                               T0042	ボールねじのリード
							   T0044	スライドテーブルの個数
							   T0045	カバー指定
							   	
	***************************************************************************	
*/

class SeinoTU_find extends ACWDB
{
	public static function get($param)
	{
		$db = new self;
		
		$sql_p = array(
			't00340' => $param['t0034'],
			't00350' => $param['t0035'],
			't00390' => $param['t0039'],
			't00420' => $param['t0042'],
			't00540' => $param['t0054'],
			't00410' => $param['t0041'],
			't00341' => $param['t0034'],
			't00351' => $param['t0035'],
			't00381' => $param['t0038'],
			't00421' => $param['t0042'],
			't00541' => $param['t0054'],
			't00342' => $param['t0034'],
			't00352' => $param['t0035'],
			't00382' => $param['t0038'],
			't00422' => $param['t0042'],
			't00542' => $param['t0054'],
			't00343' => $param['t0034'],
			't00353' => $param['t0035'],
			't00383' => $param['t0038'],
			't00393' => $param['t0039'],
			't00443' => $param['t0044'],
			't00453' => $param['t0045'],
			't00563' => $param['t0056'],
			't00413' => $param['t0041'],
			't00423' => $param['t0042'],
			't00344' => $param['t0034'],
			't00354' => $param['t0035'],
			't00384' => $param['t0038'],
			't00394' => $param['t0039'],
			't00544' => $param['t0054'],
			't00414' => $param['t0041'],
			't00345' => $param['t0034'],
			't00355' => $param['t0035'],
			't00385' => $param['t0038'],
			't00395' => $param['t0039'],
			't00545' => $param['t0054'],
			't00415' => $param['t0041'],
			't00346' => $param['t0034'],
			't00356' => $param['t0035'],
			't00386' => $param['t0038'],
			't00396' => $param['t0039'],
			't00546' => $param['t0054'],
			't00416' => $param['t0041'],
			't00347' => $param['t0034'],
			't00357' => $param['t0035'],
			't00387' => $param['t0038'],
			't00397' => $param['t0039'],
			't00547' => $param['t0054'],
			't00417' => $param['t0041'],
			't00348' => $param['t0034'],
			't00358' => $param['t0035'],
			't00388' => $param['t0038'],
			't00398' => $param['t0039'],
			't00428' => $param['t0042'],
			't00448' => $param['t0044'],
			't00458' => $param['t0045'],
			't00418' => $param['t0041']
		);
		
		$sql = "
	SELECT 			
	
			'T0027'			AS ITEM_ID
			,T0027			AS DATA
	FROM M_MAX_SPEED
	WHERE	T0034		= :t00340
		AND T0035 		= :t00350
		AND T0039		= :t00390
		AND T0042		= :t00420
		AND T0054		= :t00540
		AND T0178		= (SELECT T0178 FROM M_MOTOR WHERE T0041 = :t00410)
		AND DELETE_FLG  = 'FALSE'
	UNION 
	SELECT 

			'T0172'			
			,T0172			
	FROM M_MAX_TOSAI_SHITSURYO
	WHERE	T0034		= :t00341
		AND T0035 		= :t00351
		AND T0038		= :t00381
		AND T0042		= :t00421
		AND T0054		= :t00541
		AND DELETE_FLG  = 'FALSE'
	UNION 
	SELECT 
			'T0173'		
			,T0173			
	FROM M_MAX_TOSAI_SHITSURYO
	WHERE	T0034		= :t00342
		AND T0035 		= :t00352
		AND T0038		= :t00382
		AND T0042		= :t00422
		AND T0054		= :t00542
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
			'T0026'		
			,T0026		
	FROM M_MAX_STROKE
	WHERE   T0034		= :t00343
		AND T0035 		= :t00353
		AND T0038		= :t00383
		AND T0039		= :t00393
		AND T0042		= :t00423
		AND T0044		= :t00443
		AND T0045		= :t00453
		AND T0056		= :t00563
		AND T0179		= (SELECT T0179 FROM M_MOTOR WHERE T0041 = :t00413)
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
		 'T0157'
		 ,T0157
	FROM M_QUALITY
	WHERE	T0034		= :t00344
		AND T0035 		= :t00354
		AND T0038		= :t00384
		AND T0039		= :t00394
		AND T0054		= :t00544
		AND T0179		= (SELECT T0179 FROM M_MOTOR WHERE T0041 = :t00414)
		AND DELETE_FLG  = 'FALSE'	
	UNION
	SELECT 
		 'T0158'
		 ,T0158
	FROM M_QUALITY
	WHERE	T0034		= :t00345
		AND T0035 		= :t00355
		AND T0038		= :t00385
		AND T0039		= :t00395
		AND T0054		= :t00545
		AND T0179		= (SELECT T0179 FROM M_MOTOR WHERE T0041 = :t00415)
		AND DELETE_FLG  = 'FALSE'	
	UNION
	SELECT 
		 'T0161'
		 ,T0161
	FROM M_QUALITY
	WHERE	T0034		= :t00346
		AND T0035 		= :t00356
		AND T0038		= :t00386
		AND T0039		= :t00396
		AND T0054		= :t00546
		AND T0179		= (SELECT T0179 FROM M_MOTOR WHERE T0041 = :t00416)
		AND DELETE_FLG  = 'FALSE'	
	UNION
	SELECT 
		 'T0164'
		 ,T0164
	FROM M_QUALITY
	WHERE	T0034		= :t00347
		AND T0035 		= :t00357
		AND T0038		= :t00387
		AND T0039		= :t00397
		AND T0054		= :t00547
		AND T0179		= (SELECT T0179 FROM M_MOTOR WHERE T0041 = :t00417)
		AND DELETE_FLG  = 'FALSE'	
	UNION
	SELECT 
			'T0250'		
			,T0250		
	FROM M_SEIHIN_SHITSURYO
	WHERE   T0034		= :t00348
		AND T0035 		= :t00358
		AND T0038		= :t00388
		AND T0039		= :t00398
		AND T0042		= :t00428
		AND T0044		= :t00448
		AND T0045		= :t00458
		AND T0179		= (SELECT T0179 FROM M_MOTOR WHERE T0041 = :t00418)
		AND DELETE_FLG  = 'FALSE'
		";
		
		return $db->query($sql, $sql_p);
	}
}
