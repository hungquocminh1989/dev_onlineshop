<?php
/*
	TZ
	***************************************************************************		
		最高速度

				表示		 : T0027	

				バインド変数 : T0034	形式1
							   T0071	形式2
							   T0035	大きさ
							   T0043	くさび
							   T0041	モータアタッチメント　
										（T0178	モータ形式種類 (AC or STP)を取得） 

	***************************************************************************
		最大搭載質量　水平

				表示		 : T0172	

				バインド変数 : T0034	形式1
							   T0071	形式2
							   T0035	大きさ
							   T0043	くさび

	***************************************************************************	
		最大搭載質量　垂直

				表示		 : T0173	

				バインド変数 : T0034	形式1
							   T0071	形式2
							   T0035	大きさ
							   T0043	くさび
		
	***************************************************************************		

		最大ストローク

				表示		 : T0026	

				バインド変数 : T0034	形式1
							   T0071	形式2
							   T0035	大きさ
							   T0043	くさび
							   T0058	リニアエンコーダの指定
							   	
	***************************************************************************	

		精度

				表示		 : T0157	繰返し位置決め精度
							   T0158	位置決め精度
							   T0159	ロストモーション


				バインド変数 : T0034	形式1
							   T0071	形式2
							   T0035	大きさ
							   T0043	くさび
							   T0053	リニアエンコーダの指定
							   		
	***************************************************************************	

		製品質量

				表示		 : T0250	

				バインド変数 : T0034	形式1
							   T0071	形式2
							   T0035	大きさ
							   T0043	くさび
							   T0058	リニアエンコーダの指定
							   	
	***************************************************************************	
*/

class SeinoTZ_find extends ACWDB
{
	public static function get($param)
	{
		$db = new self;
		
		$param['t0071'] = ($param['t0071'] == Dfn::YB_KEY_NO_SYMBOL ? ' ' : $param['t0071']);
		
		$sql_p = array(
			't00340' => $param['t0034'],
			't00710' => $param['t0071'],
			't00350' => $param['t0035'],
			't00430' => $param['t0043'],
			't00410' => $param['t0041'],
			't00341' => $param['t0034'],
			't00711' => $param['t0071'],
			't00351' => $param['t0035'],
			't00431' => $param['t0043'],
			't00342' => $param['t0034'],
			't00712' => $param['t0071'],
			't00352' => $param['t0035'],
			't00432' => $param['t0043'],
			't00343' => $param['t0034'],
			't00713' => $param['t0071'],
			't00353' => $param['t0035'],
			't00433' => $param['t0043'],
			't00583' => $param['t0058'],
			't00344' => $param['t0034'],
			't00714' => $param['t0071'],
			't00354' => $param['t0035'],
			't00434' => $param['t0043'],
			't00584' => $param['t0058'],
			't00345' => $param['t0034'],
			't00715' => $param['t0071'],
			't00355' => $param['t0035'],
			't00435' => $param['t0043'],
			't00585' => $param['t0058'],
			't00346' => $param['t0034'],
			't00716' => $param['t0071'],
			't00356' => $param['t0035'],
			't00436' => $param['t0043'],
			't00586' => $param['t0058'],
			't00347' => $param['t0034'],
			't00717' => $param['t0071'],
			't00357' => $param['t0035'],
			't00437' => $param['t0043'],
			't00587' => $param['t0058']
		);
		
		$sql = "
	SELECT 			
			'T0027'			AS ITEM_ID
			,T0027			AS DATA
	FROM M_MAX_SPEED
	WHERE	T0034		= :t00340
		AND T0071		= :t00710
		AND T0035 		= :t00350
		AND T0043		= :t00430
		AND T0178		= ( SELECT T0178 FROM M_MOTOR WHERE T0041 = :t00410 )
		AND DELETE_FLG  = 'FALSE'
	UNION 
	SELECT 
			'T0172'			
			,T0172			
	FROM M_MAX_TOSAI_SHITSURYO
	WHERE	T0034		= :t00341
		AND T0071		= :t00711
		AND T0035 		= :t00351
		AND T0043		= :t00431
		AND DELETE_FLG  = 'FALSE'
	UNION 
	SELECT 
			'T0173'		
			,T0173			
	FROM M_MAX_TOSAI_SHITSURYO
	WHERE	T0034		= :t00342
		AND T0071		= :t00712
		AND T0035 		= :t00352
		AND T0043		= :t00432
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
			'T0026'		
			,T0026		
	FROM M_MAX_STROKE
	WHERE   T0034		= :t00343
		AND T0071		= :t00713
		AND T0035 		= :t00353
		AND T0043		= :t00433
		AND T0058		= :t00583
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
		 'T0157'
		 ,T0157
	FROM M_QUALITY
	WHERE	T0034		= :t00344
		AND T0071		= :t00714
		AND T0035 		= :t00354
		AND T0043		= :t00434
		AND T0058		= :t00584
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
		 'T0158'
		 ,T0158
	FROM M_QUALITY
	WHERE	T0034		= :t00345
		AND T0071		= :t00715
		AND T0035 		= :t00355
		AND T0043		= :t00435
		AND T0058		= :t00585
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
		 'T0159'
		 ,T0159
	FROM M_QUALITY
	WHERE	T0034		= :t00346
		AND T0071		= :t00716
		AND T0035 		= :t00356
		AND T0043		= :t00436
		AND T0058		= :t00586
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
		'T0250'		
		,T0250		
	FROM M_SEIHIN_SHITSURYO
	WHERE   T0034		= :t00347
		AND T0071		= :t00717
		AND T0035 		= :t00357
		AND T0043		= :t00437
		AND T0058		= :t00587
		AND DELETE_FLG  = 'FALSE'
		";
		
		return $db->query($sql, $sql_p);
	}
}
