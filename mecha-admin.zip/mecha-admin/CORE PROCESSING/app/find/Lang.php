<?php
/**
 * 言語検索
 */
class Lang_find extends ACWDB
{
	static private $DB;
	static private $SCREEN_ID;
	static private $LANG_CD;

	/**
	 * コンストラクタ
	 */
	public function __construct($screen_cd, $lang_cd, $target = '', $log_writable = true)
	{
		self::$DB = new parent($target, $log_writable);
		self::$SCREEN_ID = $screen_cd;
		self::$LANG_CD = $lang_cd;
	}

	/**
	 * 画面に表示する項目
	 */
	public function get_item_list($item_id = null)
	{
		$sql = self::_sql4items();
		
		$param = array();
		$param['screen_id'] = self::$SCREEN_ID;
		$param['lang_cd1'] = self::$LANG_CD;
		$param['item_id1'] = $item_id;
		$param['item_id2'] = $item_id;
		
		$res = self::$DB->query($sql, $param);
		
		// 項目ごとに配列に変換
		$list = array();
		foreach ($res as $row) {
			$list[$row['ITEM_ID']] = $row;
		}
		
		return $list;
	}

	/**
	 * 画面に表示する選択肢
	 */
	public function get_option_list($item_id = null)
	{
		$sql = self::_sql4options();
		
		$param = array();
		$param['screen_id1'] = self::$SCREEN_ID;
		$param['lang_cd1'] = self::$LANG_CD;
		$param['item_id1'] = $item_id;
		$param['item_id2'] = $item_id;
		
		$res = self::$DB->query($sql, $param);
		
		// 項目ごとに配列に変換
		$list = array();
		foreach ($res as $row) {
			$key = $row['ITEM_ID'];
			if (isset($list[$key]) == false) {
				$res[$key] = array();
			}
			$list[$key][] = $row;
		}
		
		return $list;
	}

	/**
	 * メッセージ
	 */
	public function get_msg_list($obj_parent_key = null)
	{
		$sql = self::_sql4msg();
		
		$param = array();
		$param['lang_cd1'] = self::$LANG_CD;
		$param['obj_parent_key1'] = $obj_parent_key;
		$param['obj_parent_key2'] = $obj_parent_key;
		
		$res = self::$DB->query($sql, $param);
		
		// 項目ごとに配列に変換
		$list = array();
		foreach ($res as $row) {
			$key = $row['OBJ_KEY'];
			$list[$key] = $row['CONVERT_STR'];
		}
		
		return $list;
	}

	/**
	 * 性能欄特殊データ
	 */
	public function get_seino_ex_list($obj_parent_key = null)
	{
		$sql = self::_sql4seino();
		
		$param = array();
		$param['lang_cd1'] = self::$LANG_CD;
		$param['obj_parent_key1'] = $obj_parent_key;
		$param['obj_parent_key2'] = $obj_parent_key;
		
		$res = self::$DB->query($sql, $param);
		
		// 項目ごとに配列に変換
		$list = array();
		foreach ($res as $row) {
			$key = $row['OBJ_KEY'];
			$list[$key] = $row['CONVERT_STR'];
		}
		
		return $list;
	}

	/**
	 * パンくずリストで使うタイトルの読み直し
	 */
	public function get_bc_title_list($title_list)
	{
		$sql = array();
		$param = array();
		
		$i = 0;
		foreach ($title_list as $key => $t) {
			$sql[] = "
				(
				SELECT
					A.SCREEN_ID
				,	A.ITEM_ID
				FROM
					M_DISPLAY_ITEM A
				WHERE
					A.SCREEN_ID = :screen_id" . $i . "
				AND	A.ITEM_ID  = :item_id" . $i . "
				AND	A.DELETE_FLG = 0
				)
			";
			$param['screen_id'. $i] = $key;
			$param['item_id'. $i] = $t['TITLE_KEY'];
			
			$i = $i + 1;
		}
		
		$sql_main = "
			SELECT
				A.SCREEN_ID
			,	A.ITEM_ID
			,	B.CONVERT_STR
			FROM
				(
				" . implode(' UNION ', $sql) . "
				) A
			JOIN
				V_LANG_CONVERSION B
				ON	A.ITEM_ID = B.OBJ_KEY
				AND	B.LANG_CD = :lang_cd1
		";
		
		$param['lang_cd1'] = self::$LANG_CD;
		
		$res = self::$DB->query($sql_main, $param);
		
		// 項目ごとに配列に変換
		$list = array();
		foreach ($res as $row) {
			$key = $row['SCREEN_ID'] . '_' . $row['ITEM_ID'];
			$list[$key] = $row['CONVERT_STR'];
		}
		
		return $list;
	}

	/**
	 * 項目用SQL
	 */
	private function _sql4items()
	{
		$sql = "
			SELECT
				A.SCREEN_ID
			,	A.ITEM_ID
			,	A.ITEM_KBN
			,	LOWER(A.ITEM_ID) AS LOW_ITEM_ID
			,	B.CONVERT_STR
			,	A.DISP_ORDER
			FROM
				M_DISPLAY_ITEM A
			JOIN
				V_LANG_CONVERSION B
				ON	A.ITEM_ID = B.OBJ_KEY
				AND	B.LANG_CD = :lang_cd1
			WHERE
				A.SCREEN_ID IN (:screen_id, 'COMMON')
			AND	(:item_id1 IS NULL OR A.ITEM_ID = :item_id2)
			AND	A.DELETE_FLG = 0
			ORDER BY
				A.DISP_ORDER ASC
			,	A.M_DISPLAY_ITEM_ID ASC
		";
		return $sql;
	}

	/**
	 * 選択肢用SQL
	 */
	private function _sql4options()
	{
		$sql = "
			SELECT
				A.SCREEN_ID
			,	A.ITEM_ID
			,	B.OBJ_KEY
			,	B.CONVERT_STR
			FROM
				M_DISPLAY_ITEM A
			JOIN
				V_LANG_CONVERSION B
				ON	A.ITEM_ID = B.OBJ_PARENT_KEY1
				AND	B.LANG_CD = :lang_cd1
				AND	B.OBJ_KBN = 'S'
			WHERE
				A.SCREEN_ID = :screen_id1
			AND	(:item_id1 IS NULL OR A.ITEM_ID = :item_id2)
			AND	A.DELETE_FLG = 0
			ORDER BY
				B.OBJ_KEY ASC
		";
		return $sql;
	}

	/**
	 * メッセージ用SQL
	 */
	private function _sql4msg()
	{
		$sql = "
			SELECT
				B.OBJ_KEY
			,	B.CONVERT_STR
			FROM
				V_LANG_CONVERSION B
			WHERE
				B.LANG_CD = :lang_cd1
			AND	B.OBJ_KBN = 'M'
			AND	(:obj_parent_key1 IS NULL OR B.OBJ_PARENT_KEY1 = :obj_parent_key2)
			ORDER BY
				B.OBJ_KEY ASC
		";
		return $sql;
	}

	/**
	 * 性能用SQL
	 */
	private function _sql4seino()
	{
		$sql = "
			SELECT
				B.OBJ_KEY
			,	B.CONVERT_STR
			FROM
				V_LANG_CONVERSION B
			WHERE
				B.LANG_CD = :lang_cd1
			AND	B.OBJ_KBN = 'X'
			AND	(:obj_parent_key1 IS NULL OR B.OBJ_PARENT_KEY1 = :obj_parent_key2)
			ORDER BY
				B.OBJ_KEY ASC
		";
		return $sql;
	}
}
