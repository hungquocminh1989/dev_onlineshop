<?php
/*
	TSLB
	***************************************************************************		
		最高速度

				表示		 : T0027	

				バインド変数 : T0034	形式1
							   T0035	大きさ

	***************************************************************************
		最大搭載質量

				表示		 : T0028	
							
				バインド変数 : T0034	形式1
							   T0035	大きさ
	
	***************************************************************************	

		最大ストローク

				表示		 : T0026	

				バインド変数 : T0034	形式1
							   T0035	大きさ
							   T0040	ストローク長さ
							   	
	***************************************************************************	

		精度

				表示		 : T0157	繰返し位置決め精度
							   T0161	テーブル運動の平行度　B


				バインド変数 : T0034	形式1
							   T0035	大きさ
							   T0040	ストローク長さ
							   		
	***************************************************************************	

		製品質量

				表示		 : T0250	

				バインド変数 : T0034	形式1
							   T0035	大きさ
							   T0040	ストローク長さ
							   	
	***************************************************************************
*/

class SeinoTSLB_find extends ACWDB
{
	public static function get($param)
	{
		$db = new self;
		
		$sql_p = array(
			't00340' => $param['t0034'],
			't00350' => $param['t0035'],
			't00341' => $param['t0034'],
			't00351' => $param['t0035'],
			't00342' => $param['t0034'],
			't00352' => $param['t0035'],
			't00402' => $param['t0040'],
			't00343' => $param['t0034'],
			't00353' => $param['t0035'],
			't00403' => $param['t0040'],
			't00344' => $param['t0034'],
			't00354' => $param['t0035'],
			't00404' => $param['t0040'],
			't00345' => $param['t0034'],
			't00355' => $param['t0035'],
			't00405' => $param['t0040']
		);
		
		$sql = "
	SELECT 			
	
			'T0027'			AS ITEM_ID
			,T0027			AS DATA
	FROM M_MAX_SPEED
	WHERE	T0034		= :t00340
		AND T0035 		= :t00350
		AND DELETE_FLG  = 'FALSE'
	UNION 
	SELECT 

			'T0028'			
			,T0028			
	FROM M_MAX_TOSAI_SHITSURYO
	WHERE	T0034		= :t00341
		AND T0035 		= :t00351
		AND DELETE_FLG  = 'FALSE'
	UNION 
	SELECT 
			'T0026'		
			,T0026		
	FROM M_MAX_STROKE
	WHERE   T0034		= :t00342
		AND T0035 		= :t00352
		AND T0040		= :t00402
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
		 'T0157'
		 ,T0157
	FROM M_QUALITY
	WHERE	T0034		= :t00343
		AND T0035 		= :t00353
		AND T0040		= :t00403
		AND DELETE_FLG  = 'FALSE'	
	UNION
	SELECT 
		 'T0161'
		 ,T0161
	FROM M_QUALITY
	WHERE	T0034		= :t00344
		AND T0035 		= :t00354
		AND T0040		= :t00404
		AND DELETE_FLG  = 'FALSE'	
	UNION
	SELECT 
		'T0250'		
		,T0250		
	FROM M_SEIHIN_SHITSURYO
	WHERE   T0034		= :t00345
		AND T0035 		= :t00355
		AND T0040		= :t00405
		AND DELETE_FLG  = 'FALSE'
		";
		
		return $db->query($sql, $sql_p);
	}
}
