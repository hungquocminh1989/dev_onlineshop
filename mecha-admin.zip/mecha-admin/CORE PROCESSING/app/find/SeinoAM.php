<?php
/*
	AM
	***************************************************************************		
		最高速度

				表示		 : T0027	

				バインド変数 : T0034	形式1
							   T0037	大きさ
							   T0042	ボールねじのリード

	***************************************************************************
		最大搭載質量　水平

				表示		 : T0172	
							
				バインド変数 : T0034	形式1
							   T0037	大きさ
	
	***************************************************************************	
		最大搭載質量　垂直

				表示		 : T0173	
							
				バインド変数 : T0034	形式1
							   T0037	大きさ
							   	
	***************************************************************************	
		最大ストローク

				表示		 : T0026	

				バインド変数 : T0034	形式1
							   T0037	大きさ
							   T0040	ストローク長さ
							   	
	***************************************************************************	

		精度

				表示		 : T0157	繰返し位置決め精度
							   T0158	位置決め精度
							   T0161	テーブル運動の平行度　B
							   T0164	バックラッシ

				バインド変数 : T0034	形式1
							   T0037	大きさ
							   T0040	ストローク長さ
							   T0054	ボールねじの種類
							   		
	***************************************************************************	
		製品質量

				表示		 : T0250	

				バインド変数 : T0034	形式1
							   T0037	大きさ
							   T0054	ボールねじ有無
							   	
	***************************************************************************	
*/

class SeinoAM_find extends ACWDB
{
	public static function get($param)
	{
		$db = new self;
		
		$sql_p = array(
			't00340' => $param['t0034'],
			't00370' => $param['t0037'],
			't00341' => $param['t0034'],
			't00371' => $param['t0037'],
			't00342' => $param['t0034'],
			't00372' => $param['t0037'],
			't00343' => $param['t0034'],
			't00373' => $param['t0037'],
			't00344' => $param['t0034'],
			't00374' => $param['t0037'],
			't00544' => $param['t0054'],
			't00345' => $param['t0034'],
			't00375' => $param['t0037'],
			't00545' => $param['t0054'],
			't00346' => $param['t0034'],
			't00376' => $param['t0037'],
			't00546' => $param['t0054'],
			't00347' => $param['t0034'],
			't00377' => $param['t0037'],
			't00547' => $param['t0054'],
			't00348' => $param['t0034'],
			't00378' => $param['t0037'],
			't00548' => $param['t0054']
		);
		
		$sql = "
	SELECT 			
		 'T0027'		AS ITEM_ID
		 ,T0027			AS DATA
	FROM M_MAX_SPEED
	WHERE	T0034		= :t00340
		AND T0037 		= :t00370
		AND DELETE_FLG  = 'FALSE'
	UNION 
	SELECT 
		 'T0172'			
		 ,T0172			
	FROM M_MAX_TOSAI_SHITSURYO
	WHERE	T0034		= :t00341
		AND T0037 		= :t00371
		AND DELETE_FLG  = 'FALSE'
	UNION 
	SELECT 
		 'T0173'			
		 ,T0173			
	FROM M_MAX_TOSAI_SHITSURYO
	WHERE	T0034		= :t00342
		AND T0037 		= :t00372
		AND DELETE_FLG  = 'FALSE'
	UNION 

	SELECT 
		 'T0026'		
		 ,T0026		
	FROM M_MAX_STROKE
	WHERE	T0034		= :t00343
		AND T0037 		= :t00373
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
		 'T0157'
		 ,T0157
	FROM M_QUALITY
	WHERE	T0034		= :t00344
		AND T0037 		= :t00374
		AND T0054		= :t00544
		AND DELETE_FLG  = 'FALSE'	
	UNION
	SELECT 
		 'T0158'
		 ,T0158
	FROM M_QUALITY
	WHERE	T0034		= :t00345
		AND T0037 		= :t00375
		AND T0054		= :t00545
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
		 'T0161'
		 ,T0161
	FROM M_QUALITY
	WHERE	T0034		= :t00346
		AND T0037 		= :t00376
		AND T0054		= :t00546
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
		 'T0164'
		 ,T0164
	FROM M_QUALITY
	WHERE	T0034		= :t00347
		AND T0037 		= :t00377
		AND T0054		= :t00547
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
		 'T0250'		
		 ,T0250		
	FROM M_SEIHIN_SHITSURYO
	WHERE	T0034		= :t00348
		AND T0037 		= :t00378
		AND T0054       = :t00548
		AND DELETE_FLG  = 'FALSE'
		";
		
		return $db->query($sql, $sql_p);
	}
}
