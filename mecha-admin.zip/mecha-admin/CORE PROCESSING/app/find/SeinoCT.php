<?php
/*
	CT
	***************************************************************************		
		最高速度

				表示		 : T0027	

				バインド変数 : T0034	形式1
							   T0036	スライドテーブルの寸法
							   T0042	ボールねじのリード
							   T0041	モータアタッチメント　
										（T0178	モータ形式種類 (AC or STP)を取得） 

	***************************************************************************
		最大搭載質量　水平

				表示		 : T0172	
							
				バインド変数 : T0034	形式1
							   T0035	大きさ(T0036:スライドテーブルの寸法)
							   T0042	ボールねじのリード
	
	***************************************************************************	
		最大搭載質量　垂直

				表示		 : T0173	

				バインド変数 : T0034	形式1
							   T0036	スライドテーブルの寸法
							   T0042	ボールねじのリード
		
	***************************************************************************		

		X軸最大ストローク

				表示		 : T0175	

				バインド変数 : T0034	形式1
							   T0036	スライドテーブルの寸法
							   	
	***************************************************************************	

		Y軸最大ストローク

				表示		 : T0176	

				バインド変数 : T0034	形式1
							   T0036	スライドテーブルの寸法
							   	
	***************************************************************************	

		精度

				表示		 : T0157	繰返し位置決め精度
							   T0158	位置決め精度
							   T0160	テーブル運動の平行度  A
							   T0161	テーブル運動の平行度　B


				バインド変数 : T0034	形式1
							   T0036	スライドテーブルの寸法
							   T0047	特別仕様
							   		
	***************************************************************************	

		製品質量

				表示		 : T0250	

				バインド変数 : T0034	形式1
							   T0036	スライドテーブルの寸法
							   	
	***************************************************************************	
*/

class SeinoCT_find extends ACWDB
{
	public static function get($param)
	{
		$db = new self;
		
		$sql_p = array(
			't00340' => $param['t0034'],
			't00360' => $param['t0036'],
			't00420' => $param['t0042'],
			't00410' => $param['t0041'],
			't00341' => $param['t0034'],
			't00361' => $param['t0036'],
			't00421' => $param['t0042'],
			't00342' => $param['t0034'],
			't00362' => $param['t0036'],
			't00422' => $param['t0042'],
			't00343' => $param['t0034'],
			't00363' => $param['t0036'],
			't00344' => $param['t0034'],
			't00364' => $param['t0036'],
			't00345' => $param['t0034'],
			't00365' => $param['t0036'],
			't00475' => $param['t0047'],
			't00346' => $param['t0034'],
			't00366' => $param['t0036'],
			't00476' => $param['t0047'],
			't00347' => $param['t0034'],
			't00367' => $param['t0036'],
			't00477' => $param['t0047'],
			't00348' => $param['t0034'],
			't00368' => $param['t0036'],
			't00478' => $param['t0047'],
			't00349' => $param['t0034'],
			't00369' => $param['t0036']
		);
		
		$sql = "
	SELECT 			
	
			'T0027'			AS ITEM_ID
			,T0027			AS DATA
	FROM M_MAX_SPEED
	WHERE	T0034		= :t00340
		AND T0036 		= :t00360
		AND T0042		= :t00420
		AND T0178		= ( SELECT T0178 FROM M_MOTOR WHERE T0041 = :t00410 )  									
		AND DELETE_FLG	= 'FALSE'
	UNION 
	SELECT 
			'T0172'			
			,T0172			
	FROM M_MAX_TOSAI_SHITSURYO
	WHERE	T0034			= :t00341
		AND T0036 			= :t00361
		AND T0042			= :t00421
		AND DELETE_FLG		= 'FALSE'
	UNION 
	SELECT 
			'T0173'		
			,T0173			
	FROM M_MAX_TOSAI_SHITSURYO
	WHERE	T0034			= :t00342
		AND T0036 			= :t00362
		AND T0042			= :t00422
		AND DELETE_FLG		= 'FALSE'
	UNION
	SELECT 
			'T0175'		
			,T0175		
	FROM M_MAX_STROKE
	WHERE   T0034			= :t00343
		AND T0036 			= :t00363
		AND DELETE_FLG  	= 'FALSE'
	UNION
	SELECT 
			'T0176'		
			,T0176	
	FROM M_MAX_STROKE
	WHERE   T0034			= :t00344
		AND T0036 			= :t00364
		AND DELETE_FLG  	= 'FALSE'
	UNION
	SELECT 
		 'T0157'
		 ,T0157
	FROM M_QUALITY
	WHERE	T0034			= :t00345
		AND T0036 			= :t00365
		AND T0047			= :t00475
		AND DELETE_FLG		= 'FALSE'	
	UNION
	SELECT 
		 'T0158'
		 ,T0158
	FROM M_QUALITY
	WHERE	T0034			= :t00346
		AND T0036 			= :t00366
		AND T0047			= :t00476
		AND DELETE_FLG		= 'FALSE'	
	UNION
	SELECT 
		 'T0160'
		 ,T0160
	FROM M_QUALITY
	WHERE	T0034			= :t00347
		AND T0036 			= :t00367
		AND T0047			= :t00477
		AND DELETE_FLG		= 'FALSE'	
	UNION
	SELECT 
		 'T0161'
		 ,T0161
	FROM M_QUALITY
	WHERE	T0034			= :t00348
		AND T0036 			= :t00368
		AND T0047			= :t00478
		AND DELETE_FLG		= 'FALSE'
	UNION
	SELECT 
		'T0250'		
		,T0250		
	FROM M_SEIHIN_SHITSURYO
	WHERE   T0034			= :t00349
		AND T0036 			= :t00369
		AND DELETE_FLG  	= 'FALSE'
		";
		
		return $db->query($sql, $sql_p);
	}
}
