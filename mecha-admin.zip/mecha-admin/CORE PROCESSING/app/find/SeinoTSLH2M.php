<?php
/*
	TSLH･･･M
	***************************************************************************		
		最高速度

				表示		 : T0027	

				バインド変数 : T0034	形式1
							   T0071	形式2
							   T0035	大きさ
							   T0042	ボールねじのリード
							   T0041	モーターアタッチメント　
										（T0178	モータ形式種類 (AC or STP)を取得） 

	***************************************************************************
		最大搭載質量 水平

				表示		 : T0172	

				バインド変数 : T0034	形式1
							   T0071	形式2
							   T0035	大きさ
							   T0042	ボールねじのリード

	***************************************************************************	
		最大搭載質量　垂直

				表示		 : T0173	

				バインド変数 : T0034	形式1
							   T0071	形式2
							   T0035	大きさ
							   T0042	ボールねじのリード
		
	***************************************************************************		

		最大ストローク

				表示		 : T0026	

				バインド変数 : T0034	形式1
							   T0071	形式2
							   T0035	大きさ
							   T0040	ストローク長さ
							   T0057	ジャバラの指定
							   
	***************************************************************************	

		精度

				表示		 : T0157	繰返し位置決め精度
							   T0158	位置決め精度
							   T0160	テーブル運動の平行度　A
							   T0163	真直度
							   T0164	バックラッシ


				バインド変数 : T0034	形式1
							   T0071	形式2
							   T0035	大きさ
							   T0040	ストローク長さ
		
	***************************************************************************	

		製品質量

				表示		 : T0250	

				バインド変数 : T0034	形式1
							   T0071	形式2
							   T0035	大きさ
							   T0040	ストローク長さ
							   T0057	ジャバラの指定
							   
	***************************************************************************	
*/

class SeinoTSLH2M_find extends ACWDB
{
	public static function get($param)
	{
		$db = new self;
		
		$sql_p = array(
			't00340' => $param['t0034'],
			't00710' => $param['t0071'],
			't00350' => $param['t0035'],
			't00420' => $param['t0042'],
			't00410' => $param['t0041'],
			't00341' => $param['t0034'],
			't00711' => $param['t0071'],
			't00351' => $param['t0035'],
			't00421' => $param['t0042'],
			't00342' => $param['t0034'],
			't00712' => $param['t0071'],
			't00352' => $param['t0035'],
			't00422' => $param['t0042'],
			't00343' => $param['t0034'],
			't00713' => $param['t0071'],
			't00353' => $param['t0035'],
			't00403' => $param['t0040'],
			't00573' => $param['t0057'],
			't00344' => $param['t0034'],
			't00714' => $param['t0071'],
			't00354' => $param['t0035'],
			't00404' => $param['t0040'],
			't00345' => $param['t0034'],
			't00715' => $param['t0071'],
			't00355' => $param['t0035'],
			't00405' => $param['t0040'],
			't00346' => $param['t0034'],
			't00716' => $param['t0071'],
			't00356' => $param['t0035'],
			't00406' => $param['t0040'],
			't00347' => $param['t0034'],
			't00717' => $param['t0071'],
			't00357' => $param['t0035'],
			't00407' => $param['t0040'],
			't00348' => $param['t0034'],
			't00718' => $param['t0071'],
			't00358' => $param['t0035'],
			't00408' => $param['t0040'],
			't00349' => $param['t0034'],
			't00719' => $param['t0071'],
			't00359' => $param['t0035'],
			't00409' => $param['t0040'],
			't00579' => $param['t0057']
		);
		
		$sql = "
	SELECT 			

			'T0027'			AS ITEM_ID
			,T0027			AS DATA
	FROM M_MAX_SPEED
	WHERE	T0034		= :t00340
		AND T0071		= :t00710
		AND T0035 		= :t00350
		AND T0042		= :t00420
		AND T0178		= (SELECT T0178 FROM M_MOTOR WHERE T0041 = :t00410)
		AND DELETE_FLG  = 'FALSE'
	UNION 
	SELECT 

			'T0172'			
			,T0172			
	FROM M_MAX_TOSAI_SHITSURYO
	WHERE	T0034		= :t00341
		AND T0071		= :t00711
		AND T0035 		= :t00351
		AND T0042		= :t00421
		AND DELETE_FLG  = 'FALSE'
	UNION 
	SELECT 

			'T0173'			
			,T0173			
	FROM M_MAX_TOSAI_SHITSURYO
	WHERE	T0034		= :t00342
		AND T0071		= :t00712
		AND T0035 		= :t00352
		AND T0042		= :t00422
		AND DELETE_FLG  = 'FALSE'
	UNION 
	SELECT 
			'T0026'		
			,T0026		
	FROM M_MAX_STROKE
	WHERE   T0034		= :t00343
		AND T0071		= :t00713
		AND T0035 		= :t00353
		AND T0040		= :t00403
		AND T0057		= :t00573
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
		 'T0157'
		 ,T0157
	FROM M_QUALITY
	WHERE	T0034		= :t00344
		AND T0071		= :t00714
		AND T0035 		= :t00354
		AND T0040		= :t00404
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
		 'T0158'
		 ,T0158
	FROM M_QUALITY
	WHERE	T0034		= :t00345
		AND T0071		= :t00715
		AND T0035 		= :t00355
		AND T0040		= :t00405
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
		 'T0160'
		 ,T0160
	FROM M_QUALITY
	WHERE	T0034		= :t00346
		AND T0071		= :t00716
		AND T0035 		= :t00356
		AND T0040		= :t00406
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
		 'T0163'
		 ,T0163
	FROM M_QUALITY
	WHERE	T0034		= :t00347
		AND T0071		= :t00717
		AND T0035 		= :t00357
		AND T0040		= :t00407
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
		 'T0164'
		 ,T0164
	FROM M_QUALITY
	WHERE	T0034		= :t00348
		AND T0071		= :t00718
		AND T0035 		= :t00358
		AND T0040		= :t00408
		AND DELETE_FLG  = 'FALSE'
	UNION
	SELECT 
			'T0250'		
			,T0250		
	FROM M_SEIHIN_SHITSURYO
	WHERE   T0034		= :t00349
		AND T0071		= :t00719
		AND T0035 		= :t00359
		AND T0040		= :t00409
		AND T0057		= :t00579
		AND DELETE_FLG  = 'FALSE'
		";
		
		return $db->query($sql, $sql_p);
	}
}
