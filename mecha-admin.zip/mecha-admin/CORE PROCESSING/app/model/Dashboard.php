
<?php
/**
 * Admindashboard
 */
class Dashboard_model extends ACWModel
{
	public static function init()
	{
		Login_model::check();
	}

	public static function action_index()
	{
		$param['title'] = '管理画面';
		return ACWView::template('dashboard.html', $param);
	}
	
}
