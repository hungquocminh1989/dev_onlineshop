<?php
/**
 * Adminlogin
 */
class Login_model extends ACWModel
{
	public static function action_index()
	{
		$param['title'] = 'ログイン';
		return ACWView::template('login.html', $param);
	}

	//IKO_VN-1 ADD START HUNG 10/7/2017 Edit Start IKO_VN-1 hungtn VNIT 20170720
	public static function action_auth()
	{
		$param = self::get_param(array('mode'));
		if($param['mode'] == 'autologout') {
			$param['msg_error'] = "一定時間操作されなかったため、自動的にログアウトしました。";
		}
		// もう一度表示
		$param['title'] = 'ログイン';
		return ACWView::template('login.html', $param);
	}//Edit End IKO_VN-1 hungtn VNIT 20170720
	
	//Edit Start IKO_VN-1 hungtn VNIT 20170720
	public static function action_checklogin() {
		$param = self::get_param(array('username', 'password'));

		$result['message'] = '';
		$result['status'] = 0;

		if(trim($param['username']) == '' || trim($param['password']) == '' ) {
			ACWError::add('message', 'ユーザーIDまたはパスワードが入力されていません。');
		} else {
			// パラメタ正常
			$login = new Login_model();
			$user_info = $login->check_login($param);
			if (is_null($user_info) == false) {
				// セッション設定
				ACWSession::set('user_info', $user_info);
				$result['status'] = 1;
				$result['redirect'] = ACW_BASE_URL . 'dashboard';
				// メニューへリダイレクト
				//return ACWView::redirect(ACW_BASE_URL . 'dashboard');
				ACWSession::set('loggedin_time', time());

				ACWLog::debug_var_action('login_model', 'action_checklogin', 'login success');//Add Start IKO_VN-1 hungtn VNIT 20170725

			} else {
				ACWError::add('message', 'ユーザーIDまたはパスワードが違います。');
			}
		}

		if($result['status'] == 0) {
			$result['message'] = ACWError::get_message();
		}

		return ACWView::json($result);
	} //EDIT End IKO_VN-1 hungtn VNIT 20170720


	public static function action_logout() {//Add Start IKO_VN-1 hungtn VNIT 20170720
		ACWSession::destroy();
		return ACWView::redirect(ACW_BASE_URL . 'login/auth');
	}//Add End IKO_VN-1 hungtn VNIT 20170720
	/**
	* DBでのログインチェック
	*/
	//Edit Start IKO_VN-1 hungtn VNIT 20170720
	public function check_login($param)
	{
		$param['password'] = md5(AKAGANE_SALT . $param['password']);
		$result = $this->query('
			SELECT
				  M_NUMBER
				, USER_ID
				, USER_NM
				
			FROM
				M_USER_ADMIN
			WHERE
				USER_ID = :username
			AND
				PASSWORD = :password
			AND
				DELETE_FLG = 0
			', $param);
		if (count($result) != 1) {
			return null;
		}
		return $result[0];
	}//Edit End IKO_VN-1 hungtn VNIT 20170720
	//IKO_VN-1 ADD END HUNG 10/7/2017

	public static function check()//Add Start IKO_VN-1 hungtn VNIT 20170720
	{
		// セッション取得
		$user_info = ACWSession::get('user_info');
		
		if (is_null($user_info)) {
			if (isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
				if (strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
					// ajaxリクエストでセッション切れ判明
					header('HTTP/1.0 401 Unauthorized');
					exit();	// 終わり
				}
			}

			ACWView::redirect(ACW_BASE_URL . 'login/auth');
			exit();
		}
		
		if(self::isLoginSessionExpired()) {
			ACWLog::debug_var_action('login_model', 'action_logout', 'セッションタイムアウトで自動的にログアウトをする。');//Add Start IKO_VN-1 hungtn VNIT 20170725
			ACWSession::destroy();
			ACWView::redirect(ACW_BASE_URL . 'login/auth?mode=autologout');
			exit();
		}
		ACWSession::set('loggedin_time', time());//Add  IKO_VN-1 hungtn VNIT 20170725
		if (isset($user_info['M_NUMBER'])) {
			// user_idがある事を条件に
			ACWView::init_template_var(array('user_info' => $user_info));
			// ログをユーザーごとに
			ACWLog::set_user_suffix($user_info['M_NUMBER']);
			return true;
		}
		return false;
	}//Add End IKO_VN-1 hungtn VNIT 20170720
	//Add Start IKO_VN-1 hungtn VNIT 20170720
	public static function isLoginSessionExpired() {
		$current_time = time(); 
		if(isset($_SESSION['loggedin_time']) and isset($_SESSION["user_info"])){  
			if(((time() - $_SESSION['loggedin_time']) > Dfn::SESSION_LOGIN_TIMEOUT)){
				return true;
			}
		}
		return false;
	}//Add End IKO_VN-1 hungtn VNIT 20170720
}
