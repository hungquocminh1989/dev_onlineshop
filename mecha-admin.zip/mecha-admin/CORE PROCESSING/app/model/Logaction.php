
<?php
/**
 * Admindashboard
 */
class Logaction_model extends ACWLog
{
	public static function write($v) {
		
		$user_info = ACWSession::get('user_info');
		if(is_array($user_info) && count($user_info) > 0) {
			ACWLog::set_user_suffix($user_info['M_NUMBER']);
		}
		
		ACWLog::debug_var('ACTION_USER', $v);
	}
}
