
<?php
/**
 * Admincsv
 */
class Csv_model extends ACWModel
{
	public static function init()
	{
		Login_model::check();
	}
	
	public static function action_index()
	{
		$result = array();
		$model = new Csv_model();
		$access_ts_year = $model->get_access_ts_year();
		$access_ts_month = $model->get_access_ts_month();
		$access_ts_day = $model->get_access_ts_day();
		$access_ts = $model->get_access_ts();
		
		$result["access_ts_year"] = $access_ts_year;
		$result["access_ts_month"] = $access_ts_month;
		$result["access_ts_day"] = $access_ts_day;
		$result["access_ts"] = $access_ts;
		
		$result["json_access_ts"] = addslashes(json_encode($access_ts));
		$result["json_access_ts_year"] = addslashes(json_encode($access_ts_year));
		$result["json_access_ts_month"] = addslashes(json_encode($access_ts_month));
		$result["json_access_ts_day"] = addslashes(json_encode($access_ts_day));

		$result["title"] = 'ログ出力';
		return ACWView::template('admincsv.html',$result,FALSE);
	}
	public static function action_download()
	{
		$param = self::get_param(array(
			  'combo_year_start',
			  'combo_month_start',
			  'combo_day_start',
			  'combo_year_end',
			  'combo_month_end',
			  'combo_day_end',
			  'combo_action_name'
		));
		
		$model = new Csv_model();
		$year_start = $param["combo_year_start"]?:"0000";
		$month_start = $param["combo_month_start"]?:"01";
		$day_start = $param["combo_day_start"]?:"01";
		
		$year_end = $param["combo_year_end"]?:"9999";
		$month_end = $param["combo_month_end"]?:"12";
		$day_end = $param["combo_day_end"]?:"31";
		
		$datefrom = $year_start."".$month_start."".$day_start;
		$dateto = $year_end."".$month_end."".$day_end;
		$action_name = $param["combo_action_name"];
		
		$res_csv = $model->get_csv_action_log($datefrom,$dateto,$action_name);

		$header = array();
		array_push($header, array('title'=>"NO", 'column'=>"NO"));
		array_push($header, array('title'=>"ユーザID", 'column'=>"USER_ID"));
		array_push($header, array('title'=>"実行時間", 'column'=>"ACCESS_TS"));
		array_push($header, array('title'=>"実行内容", 'column'=>"ACTION_NAME"));
		array_push($header, array('title'=>"型式", 'column'=>"KATASHIKI_1"));
		array_push($header, array('title'=>"選択情報", 'column'=>"MEMO2"));
		array_push($header, array('title'=>count($res_csv)."件", 'column'=>"count_row"));
		
		$filename = Dfn::CSV_ACTION_LOG_FILENAME;
		$file_path = ACW_ROOT_DIR . '/tmp/download/' . $filename;
		$csv = new Csv_lib();
		$csv->output($res_csv, $file_path, $header);
		
		return ACWView::download_file($filename, $file_path, TRUE);
	}
	
	public function get_access_ts()
	{
		$sql = "
			SELECT 
				FORMAT(ACCESS_TS, 'yyyyMMdd') as date_format,
				FORMAT(ACCESS_TS, 'yyyy') as YEAR , 
				FORMAT(ACCESS_TS, 'MM') as MONTH,
				FORMAT(ACCESS_TS, 'dd') as DAY,
				ACTION_NAME
			FROM  
				T_ACTION_LOG
			GROUP BY 
				FORMAT(ACCESS_TS, 'yyyyMMdd'),
				FORMAT(ACCESS_TS, 'yyyy') , 
				FORMAT(ACCESS_TS, 'MM'),
				FORMAT(ACCESS_TS, 'dd'),
				 ACTION_NAME
			ORDER BY FORMAT(ACCESS_TS, 'yyyyMMdd') ASC	
		";
		
		$sql_param = array();
		
		return $this->query($sql, $sql_param);
	}
	
	public function get_action_name()
	{
		$sql = "
			SELECT 
				FORMAT(ACCESS_TS, 'yyyyMMdd') as date_format,ACTION_NAME
			FROM  
				T_ACTION_LOG
			GROUP BY 
				FORMAT(ACCESS_TS, 'yyyyMMdd'),ACTION_NAME
			ORDER BY FORMAT(ACCESS_TS, 'yyyyMMdd') ASC	
		";
		
		$sql_param = array();
		
		return $this->query($sql, $sql_param);
	}
	
	public function get_access_ts_year()
	{
		$sql = "
			SELECT 
				FORMAT(ACCESS_TS, 'yyyy') as YEAR
			FROM  
				T_ACTION_LOG
			GROUP BY 
				FORMAT(ACCESS_TS, 'yyyy')
			ORDER BY FORMAT(ACCESS_TS, 'yyyy') ASC 	
		";
		
		$sql_param = array();
		
		return $this->query($sql, $sql_param);
	}
	
	public function get_access_ts_month()
	{
		$sql = "
			SELECT 
				FORMAT(ACCESS_TS, 'MM') as MONTH
			FROM  
				T_ACTION_LOG
			GROUP BY 
				FORMAT(ACCESS_TS, 'MM')
			ORDER BY FORMAT(ACCESS_TS, 'MM') ASC	
		";
		
		$sql_param = array();
		
		return $this->query($sql, $sql_param);
	}
	
	public function get_access_ts_day()
	{
		$sql = "
			SELECT 
				FORMAT(ACCESS_TS, 'dd') as DAY
			FROM  
				T_ACTION_LOG
			GROUP BY 
				FORMAT(ACCESS_TS, 'dd')
			ORDER BY FORMAT(ACCESS_TS, 'dd') ASC 	
		";
		
		$sql_param = array();
		
		return $this->query($sql, $sql_param);
	}
	
	public function get_csv_action_log($datefrom,$dateto,$action_name = "")
	{
		$sql = "
			SELECT  ROW_NUMBER() OVER(ORDER BY ACCESS_TS ASC) AS 'NO', 
					USER_ID, 
					CONCAT('''',ACCESS_TS) AS ACCESS_TS, 
					--ACCESS_TS,
					ACTION_NAME, 
					KATASHIKI_1, 
					MEMO2,
					'' AS count_row
			FROM 
					T_ACTION_LOG
		";
		$sql_param = array();
		
		$sql_where = "WHERE   1=1 ";
		$order = " ORDER BY ACCESS_TS ";
		if($datefrom != ""){
			$sql_param['from'] = $datefrom;
			$sql_where .= " AND FORMAT(ACCESS_TS, 'yyyyMMdd') >= :from ";
		}
		
		if($dateto != ""){
			$sql_param['to'] = $dateto;
			$sql_where .= " AND FORMAT(ACCESS_TS, 'yyyyMMdd') <= :to ";
		}
		
		if($action_name != ""){
			$sql_param['action_name'] = $action_name;
			$sql_where .= " AND ACTION_NAME = :action_name ";
		}
		
		return $this->query($sql.$sql_where.$order, $sql_param);
	}
}
